import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, bigint, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Contacts table - stores imported contacts from CSV
 */
export const contacts = mysqlTable("contacts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  email: varchar("email", { length: 320 }),
  customField1: text("customField1"),
  customField2: text("customField2"),
  customField3: text("customField3"),
  customField4: text("customField4"),
  customField5: text("customField5"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = typeof contacts.$inferInsert;

/**
 * Audio files table - stores uploaded audio files for campaigns and MOH
 */
export const audioFiles = mysqlTable("audioFiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  filename: varchar("filename", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 512 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileSize: int("fileSize").notNull(),
  mimeType: varchar("mimeType", { length: 100 }).notNull(),
  duration: int("duration"), // duration in seconds
  type: mysqlEnum("type", ["campaign", "moh"]).notNull(), // campaign audio or music on hold
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AudioFile = typeof audioFiles.$inferSelect;
export type InsertAudioFile = typeof audioFiles.$inferInsert;

/**
 * Extensions table - SIP extensions/ramais configuration
 */
export const extensions = mysqlTable("extensions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  extension: varchar("extension", { length: 20 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  secret: varchar("secret", { length: 255 }).notNull(),
  context: varchar("context", { length: 100 }).default("from-internal").notNull(),
  callerIdName: varchar("callerIdName", { length: 255 }),
  callerIdNumber: varchar("callerIdNumber", { length: 20 }),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Extension = typeof extensions.$inferSelect;
export type InsertExtension = typeof extensions.$inferInsert;

/**
 * Queues table - call queues configuration
 */
export const queues = mysqlTable("queues", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  displayName: varchar("displayName", { length: 255 }).notNull(),
  strategy: mysqlEnum("strategy", ["ringall", "leastrecent", "fewestcalls", "random", "rrmemory"]).default("ringall").notNull(),
  timeout: int("timeout").default(30).notNull(),
  retry: int("retry").default(5).notNull(),
  maxlen: int("maxlen").default(0).notNull(),
  musicOnHold: varchar("musicOnHold", { length: 255 }),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Queue = typeof queues.$inferSelect;
export type InsertQueue = typeof queues.$inferInsert;

/**
 * Queue members table - associates extensions with queues
 */
export const queueMembers = mysqlTable("queueMembers", {
  id: int("id").autoincrement().primaryKey(),
  queueId: int("queueId").notNull(),
  extensionId: int("extensionId").notNull(),
  penalty: int("penalty").default(0).notNull(),
  paused: boolean("paused").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type QueueMember = typeof queueMembers.$inferSelect;
export type InsertQueueMember = typeof queueMembers.$inferInsert;

/**
 * SIP trunks table - external SIP trunk configuration
 */
export const sipTrunks = mysqlTable("sipTrunks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  host: varchar("host", { length: 255 }).notNull(),
  username: varchar("username", { length: 255 }).notNull(),
  secret: varchar("secret", { length: 255 }).notNull(),
  port: int("port").default(5060).notNull(),
  context: varchar("context", { length: 100 }).default("from-trunk").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SipTrunk = typeof sipTrunks.$inferSelect;
export type InsertSipTrunk = typeof sipTrunks.$inferInsert;

/**
 * Campaigns table - voice blast campaigns
 */
export const campaigns = mysqlTable("campaigns", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  audioFileId: int("audioFileId").notNull(),
  trunkId: int("trunkId").notNull(),
  maxConcurrentCalls: int("maxConcurrentCalls").default(10).notNull(),
  status: mysqlEnum("status", ["draft", "scheduled", "running", "paused", "completed", "cancelled"]).default("draft").notNull(),
  scheduledAt: timestamp("scheduledAt"),
  startedAt: timestamp("startedAt"),
  completedAt: timestamp("completedAt"),
  ivrEnabled: boolean("ivrEnabled").default(false).notNull(),
  ivrOptions: text("ivrOptions"), // JSON string with IVR menu options
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = typeof campaigns.$inferInsert;

/**
 * Campaign contacts table - associates contacts with campaigns
 */
export const campaignContacts = mysqlTable("campaignContacts", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").notNull(),
  contactId: int("contactId").notNull(),
  status: mysqlEnum("status", ["pending", "calling", "completed", "failed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CampaignContact = typeof campaignContacts.$inferSelect;
export type InsertCampaignContact = typeof campaignContacts.$inferInsert;

/**
 * Call logs table - detailed call records
 */
export const callLogs = mysqlTable("callLogs", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").notNull(),
  contactId: int("contactId").notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  status: mysqlEnum("status", ["answered", "no-answer", "busy", "failed", "voicemail"]).notNull(),
  duration: int("duration").default(0).notNull(), // call duration in seconds
  ivrOption: varchar("ivrOption", { length: 10 }), // digit pressed by customer
  callStartTime: timestamp("callStartTime").notNull(),
  callEndTime: timestamp("callEndTime"),
  asteriskCallId: varchar("asteriskCallId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CallLog = typeof callLogs.$inferSelect;
export type InsertCallLog = typeof callLogs.$inferInsert;

/**
 * System settings table - global system configuration
 */
export const systemSettings = mysqlTable("systemSettings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = typeof systemSettings.$inferInsert;

/**
 * IVR Actions table - stores IVR menu configuration for campaigns
 */
export const ivrActions = mysqlTable("ivrActions", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").notNull(),
  digit: varchar("digit", { length: 1 }).notNull(), // 0-9, *, #
  actionType: mysqlEnum("actionType", ["transfer_queue", "transfer_extension", "repeat_menu", "hangup", "play_audio", "custom"]).notNull(),
  queueId: int("queueId"), // for transfer_queue
  extensionId: int("extensionId"), // for transfer_extension
  audioFileId: int("audioFileId"), // for play_audio
  customData: text("customData"), // JSON for custom actions
  description: varchar("description", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type IVRAction = typeof ivrActions.$inferSelect;
export type InsertIVRAction = typeof ivrActions.$inferInsert;

/**
 * TTS Settings table - Text-to-Speech configuration
 */
export const ttsSettings = mysqlTable("ttsSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  campaignId: int("campaignId").notNull(),
  enabled: boolean("enabled").default(false).notNull(),
  introAudioFileId: int("introAudioFileId"), // Audio that plays before TTS (e.g., "Alo, eu falo com")
  language: varchar("language", { length: 10 }).default("pt-BR").notNull(),
  voice: varchar("voice", { length: 50 }).default("female").notNull(),
  provider: varchar("provider", { length: 50 }).default("google").notNull(), // google, aws, azure
  speed: varchar("speed", { length: 10 }).default("1.0"), // 0.5 to 2.0
  pitch: varchar("pitch", { length: 10 }).default("1.0"), // 0.5 to 2.0
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TTSSetting = typeof ttsSettings.$inferSelect;
export type InsertTTSSetting = typeof ttsSettings.$inferInsert;

/**
 * TTS Cache table - stores generated TTS audio files
 */
export const ttsCache = mysqlTable("ttsCache", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  text: text("text").notNull(),
  language: varchar("language", { length: 10 }).notNull(),
  voice: varchar("voice", { length: 50 }).notNull(),
  audioFileId: int("audioFileId"), // Reference to generated audio file
  audioUrl: text("audioUrl"), // URL to the generated audio
  expiresAt: timestamp("expiresAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TTSCache = typeof ttsCache.$inferSelect;
export type InsertTTSCache = typeof ttsCache.$inferInsert;

/**
 * Campaign Pause State table - stores campaign pause/resume state
 */
export const campaignPauseState = mysqlTable("campaignPauseState", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").notNull().unique(),
  status: mysqlEnum("status", ["running", "paused", "completed"]).default("running").notNull(),
  lastContactIndex: int("lastContactIndex").default(0).notNull(), // Index of last processed contact
  totalContacts: int("totalContacts").default(0).notNull(),
  processedContacts: int("processedContacts").default(0).notNull(),
  successfulCalls: int("successfulCalls").default(0).notNull(),
  failedCalls: int("failedCalls").default(0).notNull(),
  pausedAt: timestamp("pausedAt"),
  resumedAt: timestamp("resumedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CampaignPauseState = typeof campaignPauseState.$inferSelect;
export type InsertCampaignPauseState = typeof campaignPauseState.$inferInsert;

/**
 * Extension Status table - real-time status of extensions
 */
export const extensionStatus = mysqlTable("extensionStatus", {
  id: int("id").autoincrement().primaryKey(),
  extensionId: int("extensionId").notNull().unique(),
  status: mysqlEnum("status", ["online", "offline", "available", "busy", "dnd"]).default("offline").notNull(),
  currentCall: varchar("currentCall", { length: 255 }), // Current call ID if busy
  lastStatusChange: timestamp("lastStatusChange").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ExtensionStatus = typeof extensionStatus.$inferSelect;
export type InsertExtensionStatus = typeof extensionStatus.$inferInsert;
