CREATE TABLE `campaignPauseState` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` int NOT NULL,
	`status` enum('running','paused','completed') NOT NULL DEFAULT 'running',
	`lastContactIndex` int NOT NULL DEFAULT 0,
	`totalContacts` int NOT NULL DEFAULT 0,
	`processedContacts` int NOT NULL DEFAULT 0,
	`successfulCalls` int NOT NULL DEFAULT 0,
	`failedCalls` int NOT NULL DEFAULT 0,
	`pausedAt` timestamp,
	`resumedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `campaignPauseState_id` PRIMARY KEY(`id`),
	CONSTRAINT `campaignPauseState_campaignId_unique` UNIQUE(`campaignId`)
);
--> statement-breakpoint
CREATE TABLE `extensionStatus` (
	`id` int AUTO_INCREMENT NOT NULL,
	`extensionId` int NOT NULL,
	`status` enum('online','offline','available','busy','dnd') NOT NULL DEFAULT 'offline',
	`currentCall` varchar(255),
	`lastStatusChange` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `extensionStatus_id` PRIMARY KEY(`id`),
	CONSTRAINT `extensionStatus_extensionId_unique` UNIQUE(`extensionId`)
);
--> statement-breakpoint
CREATE TABLE `ivrActions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` int NOT NULL,
	`digit` varchar(1) NOT NULL,
	`actionType` enum('transfer_queue','transfer_extension','repeat_menu','hangup','play_audio','custom') NOT NULL,
	`queueId` int,
	`extensionId` int,
	`audioFileId` int,
	`customData` text,
	`description` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ivrActions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ttsCache` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`text` text NOT NULL,
	`language` varchar(10) NOT NULL,
	`voice` varchar(50) NOT NULL,
	`audioFileId` int,
	`audioUrl` text,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ttsCache_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ttsSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`campaignId` int NOT NULL,
	`enabled` boolean NOT NULL DEFAULT false,
	`introAudioFileId` int,
	`language` varchar(10) NOT NULL DEFAULT 'pt-BR',
	`voice` varchar(50) NOT NULL DEFAULT 'female',
	`provider` varchar(50) NOT NULL DEFAULT 'google',
	`speed` varchar(10) DEFAULT '1.0',
	`pitch` varchar(10) DEFAULT '1.0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ttsSettings_id` PRIMARY KEY(`id`)
);
