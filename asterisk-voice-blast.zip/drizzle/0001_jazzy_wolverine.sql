CREATE TABLE `audioFiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`filename` varchar(255) NOT NULL,
	`fileKey` varchar(512) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileSize` int NOT NULL,
	`mimeType` varchar(100) NOT NULL,
	`duration` int,
	`type` enum('campaign','moh') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audioFiles_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `callLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` int NOT NULL,
	`contactId` int NOT NULL,
	`phone` varchar(20) NOT NULL,
	`status` enum('answered','no-answer','busy','failed','voicemail') NOT NULL,
	`duration` int NOT NULL DEFAULT 0,
	`ivrOption` varchar(10),
	`callStartTime` timestamp NOT NULL,
	`callEndTime` timestamp,
	`asteriskCallId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `callLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `campaignContacts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` int NOT NULL,
	`contactId` int NOT NULL,
	`status` enum('pending','calling','completed','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `campaignContacts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `campaigns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`audioFileId` int NOT NULL,
	`trunkId` int NOT NULL,
	`maxConcurrentCalls` int NOT NULL DEFAULT 10,
	`status` enum('draft','scheduled','running','paused','completed','cancelled') NOT NULL DEFAULT 'draft',
	`scheduledAt` timestamp,
	`startedAt` timestamp,
	`completedAt` timestamp,
	`ivrEnabled` boolean NOT NULL DEFAULT false,
	`ivrOptions` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `campaigns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contacts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`email` varchar(320),
	`customField1` text,
	`customField2` text,
	`customField3` text,
	`customField4` text,
	`customField5` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contacts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `extensions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`extension` varchar(20) NOT NULL,
	`name` varchar(255) NOT NULL,
	`secret` varchar(255) NOT NULL,
	`context` varchar(100) NOT NULL DEFAULT 'from-internal',
	`callerIdName` varchar(255),
	`callerIdNumber` varchar(20),
	`enabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `extensions_id` PRIMARY KEY(`id`),
	CONSTRAINT `extensions_extension_unique` UNIQUE(`extension`)
);
--> statement-breakpoint
CREATE TABLE `queueMembers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`queueId` int NOT NULL,
	`extensionId` int NOT NULL,
	`penalty` int NOT NULL DEFAULT 0,
	`paused` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `queueMembers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `queues` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`displayName` varchar(255) NOT NULL,
	`strategy` enum('ringall','leastrecent','fewestcalls','random','rrmemory') NOT NULL DEFAULT 'ringall',
	`timeout` int NOT NULL DEFAULT 30,
	`retry` int NOT NULL DEFAULT 5,
	`maxlen` int NOT NULL DEFAULT 0,
	`musicOnHold` varchar(255),
	`enabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `queues_id` PRIMARY KEY(`id`),
	CONSTRAINT `queues_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `sipTrunks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`host` varchar(255) NOT NULL,
	`username` varchar(255) NOT NULL,
	`secret` varchar(255) NOT NULL,
	`port` int NOT NULL DEFAULT 5060,
	`context` varchar(100) NOT NULL DEFAULT 'from-trunk',
	`enabled` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sipTrunks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `systemSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`key` varchar(100) NOT NULL,
	`value` text NOT NULL,
	`description` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `systemSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `systemSettings_key_unique` UNIQUE(`key`)
);
