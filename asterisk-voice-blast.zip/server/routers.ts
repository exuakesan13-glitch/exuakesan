import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { parseCSV, generateCSVTemplate } from "./csvProcessor";
import { storagePut } from "./storage";
import { 
  generateSipConf, 
  generateTrunkConf, 
  generateQueuesConf,
  generateCampaignDialplan,
  checkAsteriskStatus,
  reloadAsteriskConfig,
  getActiveChannelsCount,
  originateCall
} from "./asterisk";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ============= Contacts Management =============
  contacts: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getContactsByUserId(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        phone: z.string().min(10),
        email: z.string().email().optional(),
        customField1: z.string().optional(),
        customField2: z.string().optional(),
        customField3: z.string().optional(),
        customField4: z.string().optional(),
        customField5: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return await db.createContact({
          userId: ctx.user.id,
          ...input,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        phone: z.string().min(10).optional(),
        email: z.string().email().optional(),
        customField1: z.string().optional(),
        customField2: z.string().optional(),
        customField3: z.string().optional(),
        customField4: z.string().optional(),
        customField5: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateContact(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteContact(input.id);
        return { success: true };
      }),

    importCSV: protectedProcedure
      .input(z.object({
        csvContent: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = parseCSV(input.csvContent);
        
        if (!result.success) {
          return {
            success: false,
            errors: result.errors,
            imported: 0,
          };
        }

        const contactsToInsert = result.contacts.map(contact => ({
          userId: ctx.user.id,
          ...contact,
        }));

        await db.bulkCreateContacts(contactsToInsert);

        return {
          success: true,
          imported: result.validRows,
          errors: result.errors,
          totalRows: result.totalRows,
        };
      }),

    downloadTemplate: protectedProcedure.query(() => {
      return {
        content: generateCSVTemplate(),
        filename: "contacts_template.csv",
      };
    }),
  }),

  // ============= Audio Files Management =============
  audioFiles: router({
    list: protectedProcedure
      .input(z.object({
        type: z.enum(["campaign", "moh"]).optional(),
      }))
      .query(async ({ ctx, input }) => {
        return await db.getAudioFilesByUserId(ctx.user.id, input.type);
      }),

    upload: protectedProcedure
      .input(z.object({
        name: z.string(),
        filename: z.string(),
        fileData: z.string(), // base64 encoded
        mimeType: z.string(),
        type: z.enum(["campaign", "moh"]),
        duration: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.fileData, 'base64');
        const fileKey = `audio/${ctx.user.id}/${Date.now()}-${input.filename}`;
        
        const { url } = await storagePut(fileKey, buffer, input.mimeType);

        return await db.createAudioFile({
          userId: ctx.user.id,
          name: input.name,
          filename: input.filename,
          fileKey,
          fileUrl: url,
          fileSize: buffer.length,
          mimeType: input.mimeType,
          duration: input.duration,
          type: input.type,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteAudioFile(input.id);
        return { success: true };
      }),
  }),

  // ============= Extensions Management =============
  extensions: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getExtensionsByUserId(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({
        extension: z.string().min(2),
        name: z.string().min(1),
        secret: z.string().min(6),
        context: z.string().default("from-internal"),
        callerIdName: z.string().optional(),
        callerIdNumber: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const extension = await db.createExtension({
          userId: ctx.user.id,
          ...input,
          enabled: true,
        });

        // Generate new SIP configuration
        const allExtensions = await db.getExtensionsByUserId(ctx.user.id);
        const sipConf = generateSipConf(allExtensions);
        
        return { extension, sipConf };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        secret: z.string().optional(),
        context: z.string().optional(),
        callerIdName: z.string().optional(),
        callerIdNumber: z.string().optional(),
        enabled: z.boolean().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        await db.updateExtension(id, data);
        
        const allExtensions = await db.getExtensionsByUserId(ctx.user.id);
        const sipConf = generateSipConf(allExtensions);
        
        return { success: true, sipConf };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteExtension(input.id);
        
        const allExtensions = await db.getExtensionsByUserId(ctx.user.id);
        const sipConf = generateSipConf(allExtensions);
        
        return { success: true, sipConf };
      }),

    generateConfig: protectedProcedure.query(async ({ ctx }) => {
      const extensions = await db.getExtensionsByUserId(ctx.user.id);
      return { config: generateSipConf(extensions) };
    }),
  }),

  // ============= Queues Management =============
  queues: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getQueuesByUserId(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        displayName: z.string().min(1),
        strategy: z.enum(["ringall", "leastrecent", "fewestcalls", "random", "rrmemory"]),
        timeout: z.number().default(30),
        retry: z.number().default(5),
        maxlen: z.number().default(0),
        musicOnHold: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        return await db.createQueue({
          userId: ctx.user.id,
          ...input,
          enabled: true,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        displayName: z.string().optional(),
        strategy: z.enum(["ringall", "leastrecent", "fewestcalls", "random", "rrmemory"]).optional(),
        timeout: z.number().optional(),
        retry: z.number().optional(),
        maxlen: z.number().optional(),
        musicOnHold: z.string().optional(),
        enabled: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateQueue(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteQueue(input.id);
        return { success: true };
      }),

    getMembers: protectedProcedure
      .input(z.object({ queueId: z.number() }))
      .query(async ({ input }) => {
        return await db.getQueueMembers(input.queueId);
      }),

    addMember: protectedProcedure
      .input(z.object({
        queueId: z.number(),
        extensionId: z.number(),
        penalty: z.number().default(0),
      }))
      .mutation(async ({ input }) => {
        return await db.addQueueMember(input);
      }),

    removeMember: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.removeQueueMember(input.id);
        return { success: true };
      }),

    generateConfig: protectedProcedure.query(async ({ ctx }) => {
      const queues = await db.getQueuesByUserId(ctx.user.id);
      return { config: generateQueuesConf(queues) };
    }),
  }),

  // ============= SIP Trunks Management =============
  trunks: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getSipTrunksByUserId(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        host: z.string().min(1),
        username: z.string().min(1),
        secret: z.string().min(1),
        port: z.number().default(5060),
        context: z.string().default("from-trunk"),
      }))
      .mutation(async ({ ctx, input }) => {
        return await db.createSipTrunk({
          userId: ctx.user.id,
          ...input,
          enabled: true,
        });
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        host: z.string().optional(),
        username: z.string().optional(),
        secret: z.string().optional(),
        port: z.number().optional(),
        context: z.string().optional(),
        enabled: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateSipTrunk(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteSipTrunk(input.id);
        return { success: true };
      }),

    generateConfig: protectedProcedure.query(async ({ ctx }) => {
      const trunks = await db.getSipTrunksByUserId(ctx.user.id);
      return { config: generateTrunkConf(trunks) };
    }),
  }),

  // ============= Campaigns Management =============
  campaigns: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getCampaignsByUserId(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getCampaignById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        audioFileId: z.number(),
        trunkId: z.number(),
        maxConcurrentCalls: z.number().default(10),
        ivrEnabled: z.boolean().default(false),
        ivrOptions: z.string().optional(),
        contactIds: z.array(z.number()),
      }))
      .mutation(async ({ ctx, input }) => {
        const { contactIds, ...campaignData } = input;
        
        const campaign = await db.createCampaign({
          userId: ctx.user.id,
          ...campaignData,
          status: "draft",
        });

        // Add contacts to campaign
        const campaignContactsList = contactIds.map(contactId => ({
          campaignId: campaign.id,
          contactId,
          status: "pending" as const,
        }));

        await db.bulkAddCampaignContacts(campaignContactsList);

        return campaign;
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        audioFileId: z.number().optional(),
        trunkId: z.number().optional(),
        maxConcurrentCalls: z.number().optional(),
        status: z.enum(["draft", "scheduled", "running", "paused", "completed", "cancelled"]).optional(),
        ivrEnabled: z.boolean().optional(),
        ivrOptions: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateCampaign(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteCampaign(input.id);
        return { success: true };
      }),

    start: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateCampaign(input.id, {
          status: "running",
          startedAt: new Date(),
        });
        return { success: true };
      }),

    pause: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateCampaign(input.id, { status: "paused" });
        return { success: true };
      }),

    resume: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateCampaign(input.id, { status: "running" });
        return { success: true };
      }),

    getContacts: protectedProcedure
      .input(z.object({ campaignId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCampaignContacts(input.campaignId);
      }),
  }),

  // ============= Call Logs & Reports =============
  reports: router({
    callLogs: protectedProcedure
      .input(z.object({ campaignId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCallLogsByCampaignId(input.campaignId);
      }),

    stats: protectedProcedure
      .input(z.object({ campaignId: z.number() }))
      .query(async ({ input }) => {
        const stats = await db.getCallLogStats(input.campaignId);
        
        const summary = {
          answered: 0,
          noAnswer: 0,
          busy: 0,
          failed: 0,
          voicemail: 0,
          total: 0,
        };

        if (stats) {
          for (const stat of stats) {
            summary.total += stat.count;
            switch (stat.status) {
              case "answered":
                summary.answered = stat.count;
                break;
              case "no-answer":
                summary.noAnswer = stat.count;
                break;
              case "busy":
                summary.busy = stat.count;
                break;
              case "failed":
                summary.failed = stat.count;
                break;
              case "voicemail":
                summary.voicemail = stat.count;
                break;
            }
          }
        }

        return summary;
      }),
  }),

  // ============= Real-time Monitoring =============
  monitoring: router({
    activeCalls: protectedProcedure.query(async () => {
      const calls = await db.getActiveCalls();
      return calls;
    }),

    liveStats: protectedProcedure.query(async ({ ctx }) => {
      const runningCampaigns = await db.getRunningCampaigns(ctx.user.id);
      const activeChannels = await getActiveChannelsCount();
      const todayCallLogs = await db.getTodayCallLogs(ctx.user.id);
      
      const stats = {
        answered: 0,
        noAnswer: 0,
        busy: 0,
        failed: 0,
        voicemail: 0,
        total: 0,
      };

      for (const log of todayCallLogs) {
        stats.total++;
        switch (log.status) {
          case "answered":
            stats.answered++;
            break;
          case "no-answer":
            stats.noAnswer++;
            break;
          case "busy":
            stats.busy++;
            break;
          case "failed":
            stats.failed++;
            break;
          case "voicemail":
            stats.voicemail++;
            break;
        }
      }

      return {
        runningCampaigns: runningCampaigns.length,
        activeChannels,
        todayStats: stats,
        campaigns: runningCampaigns,
      };
    }),
  }),

  // ============= System Status =============
  status: router({
    asterisk: protectedProcedure.query(async () => {
      return await checkAsteriskStatus();
    }),

    activeChannels: protectedProcedure.query(async () => {
      const count = await getActiveChannelsCount();
      return { count };
    }),

    reload: protectedProcedure
      .input(z.object({
        module: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await reloadAsteriskConfig(input.module);
      }),
  }),
});

export type AppRouter = typeof appRouter;
