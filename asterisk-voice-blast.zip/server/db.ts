import { eq, and, desc, asc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  contacts, InsertContact, Contact,
  audioFiles, InsertAudioFile, AudioFile,
  extensions, InsertExtension, Extension,
  queues, InsertQueue, Queue,
  queueMembers, InsertQueueMember, QueueMember,
  sipTrunks, InsertSipTrunk, SipTrunk,
  campaigns, InsertCampaign, Campaign,
  campaignContacts, InsertCampaignContact, CampaignContact,
  callLogs, InsertCallLog, CallLog,
  systemSettings, InsertSystemSetting, SystemSetting,
  ivrActions, InsertIVRAction, IVRAction,
  ttsSettings, InsertTTSSetting, TTSSetting,
  ttsCache, InsertTTSCache, TTSCache,
  campaignPauseState, InsertCampaignPauseState, CampaignPauseState,
  extensionStatus, InsertExtensionStatus, ExtensionStatus
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============= User Management =============
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============= Contacts Management =============
export async function createContact(contact: InsertContact): Promise<Contact> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(contacts).values(contact);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(contacts).where(eq(contacts.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getContactsByUserId(userId: number): Promise<Contact[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(contacts).where(eq(contacts.userId, userId)).orderBy(desc(contacts.createdAt));
}

export async function getContactById(id: number): Promise<Contact | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(contacts).where(eq(contacts.id, id)).limit(1);
  return result[0];
}

export async function updateContact(id: number, data: Partial<InsertContact>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(contacts).set(data).where(eq(contacts.id, id));
}

export async function deleteContact(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(contacts).where(eq(contacts.id, id));
}

export async function bulkCreateContacts(contactsList: InsertContact[]): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  if (contactsList.length === 0) return;
  await db.insert(contacts).values(contactsList);
}

// ============= Audio Files Management =============
export async function createAudioFile(audio: InsertAudioFile): Promise<AudioFile> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(audioFiles).values(audio);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(audioFiles).where(eq(audioFiles.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getAudioFilesByUserId(userId: number, type?: "campaign" | "moh"): Promise<AudioFile[]> {
  const db = await getDb();
  if (!db) return [];
  
  if (type) {
    return await db.select().from(audioFiles)
      .where(and(eq(audioFiles.userId, userId), eq(audioFiles.type, type)))
      .orderBy(desc(audioFiles.createdAt));
  }
  
  return await db.select().from(audioFiles)
    .where(eq(audioFiles.userId, userId))
    .orderBy(desc(audioFiles.createdAt));
}

export async function getAudioFileById(id: number): Promise<AudioFile | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(audioFiles).where(eq(audioFiles.id, id)).limit(1);
  return result[0];
}

export async function deleteAudioFile(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(audioFiles).where(eq(audioFiles.id, id));
}

// ============= Extensions Management =============
export async function createExtension(extension: InsertExtension): Promise<Extension> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(extensions).values(extension);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(extensions).where(eq(extensions.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getExtensionsByUserId(userId: number): Promise<Extension[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(extensions).where(eq(extensions.userId, userId)).orderBy(asc(extensions.extension));
}

export async function getExtensionById(id: number): Promise<Extension | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(extensions).where(eq(extensions.id, id)).limit(1);
  return result[0];
}

export async function updateExtension(id: number, data: Partial<InsertExtension>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(extensions).set(data).where(eq(extensions.id, id));
}

export async function deleteExtension(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(extensions).where(eq(extensions.id, id));
}

// ============= Queues Management =============
export async function createQueue(queue: InsertQueue): Promise<Queue> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(queues).values(queue);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(queues).where(eq(queues.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getQueuesByUserId(userId: number): Promise<Queue[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(queues).where(eq(queues.userId, userId)).orderBy(asc(queues.name));
}

export async function getQueueById(id: number): Promise<Queue | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(queues).where(eq(queues.id, id)).limit(1);
  return result[0];
}

export async function updateQueue(id: number, data: Partial<InsertQueue>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(queues).set(data).where(eq(queues.id, id));
}

export async function deleteQueue(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(queues).where(eq(queues.id, id));
}

// ============= Queue Members Management =============
export async function addQueueMember(member: InsertQueueMember): Promise<QueueMember> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(queueMembers).values(member);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(queueMembers).where(eq(queueMembers.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getQueueMembers(queueId: number): Promise<QueueMember[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(queueMembers).where(eq(queueMembers.queueId, queueId));
}

export async function removeQueueMember(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(queueMembers).where(eq(queueMembers.id, id));
}

export async function updateQueueMember(id: number, data: Partial<InsertQueueMember>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(queueMembers).set(data).where(eq(queueMembers.id, id));
}

// ============= SIP Trunks Management =============
export async function createSipTrunk(trunk: InsertSipTrunk): Promise<SipTrunk> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(sipTrunks).values(trunk);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(sipTrunks).where(eq(sipTrunks.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getSipTrunksByUserId(userId: number): Promise<SipTrunk[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(sipTrunks).where(eq(sipTrunks.userId, userId)).orderBy(asc(sipTrunks.name));
}

export async function getSipTrunkById(id: number): Promise<SipTrunk | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(sipTrunks).where(eq(sipTrunks.id, id)).limit(1);
  return result[0];
}

export async function updateSipTrunk(id: number, data: Partial<InsertSipTrunk>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(sipTrunks).set(data).where(eq(sipTrunks.id, id));
}

export async function deleteSipTrunk(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(sipTrunks).where(eq(sipTrunks.id, id));
}

// ============= Campaigns Management =============
export async function createCampaign(campaign: InsertCampaign): Promise<Campaign> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(campaigns).values(campaign);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(campaigns).where(eq(campaigns.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getCampaignsByUserId(userId: number): Promise<Campaign[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(campaigns).where(eq(campaigns.userId, userId)).orderBy(desc(campaigns.createdAt));
}

export async function getCampaignById(id: number): Promise<Campaign | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(campaigns).where(eq(campaigns.id, id)).limit(1);
  return result[0];
}

export async function updateCampaign(id: number, data: Partial<InsertCampaign>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(campaigns).set(data).where(eq(campaigns.id, id));
}

export async function deleteCampaign(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(campaigns).where(eq(campaigns.id, id));
}

// ============= Campaign Contacts Management =============
export async function addCampaignContact(campaignContact: InsertCampaignContact): Promise<CampaignContact> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(campaignContacts).values(campaignContact);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(campaignContacts).where(eq(campaignContacts.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function bulkAddCampaignContacts(campaignContactsList: InsertCampaignContact[]): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  if (campaignContactsList.length === 0) return;
  await db.insert(campaignContacts).values(campaignContactsList);
}

export async function getCampaignContacts(campaignId: number): Promise<CampaignContact[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(campaignContacts).where(eq(campaignContacts.campaignId, campaignId));
}

export async function updateCampaignContact(id: number, data: Partial<InsertCampaignContact>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(campaignContacts).set(data).where(eq(campaignContacts.id, id));
}

// ============= Call Logs Management =============
export async function createCallLog(callLog: InsertCallLog): Promise<CallLog> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(callLogs).values(callLog);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(callLogs).where(eq(callLogs.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getCallLogsByCampaignId(campaignId: number): Promise<CallLog[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(callLogs)
    .where(eq(callLogs.campaignId, campaignId))
    .orderBy(desc(callLogs.callStartTime));
}

export async function getCallLogStats(campaignId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const stats = await db
    .select({
      status: callLogs.status,
      count: sql<number>`count(*)`.as('count'),
    })
    .from(callLogs)
    .where(eq(callLogs.campaignId, campaignId))
    .groupBy(callLogs.status);
  
  return stats;
}

// ============= System Settings Management =============
export async function getSystemSetting(key: string): Promise<SystemSetting | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(systemSettings).where(eq(systemSettings.key, key)).limit(1);
  return result[0];
}

export async function setSystemSetting(setting: InsertSystemSetting): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(systemSettings).values(setting).onDuplicateKeyUpdate({
    set: { value: setting.value, updatedAt: new Date() },
  });
}

export async function getAllSystemSettings(): Promise<SystemSetting[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(systemSettings);
}

// ============= Real-time Monitoring =============
export async function getActiveCalls(): Promise<CallLog[]> {
  const db = await getDb();
  if (!db) return [];
  
  // Retorna chamadas que começaram nos últimos 5 minutos e ainda não terminaram
  const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
  
  return await db.select().from(callLogs)
    .where(
      and(
        sql`${callLogs.callStartTime} >= ${fiveMinutesAgo}`,
        sql`${callLogs.duration} IS NULL OR ${callLogs.duration} = 0`
      )
    )
    .orderBy(desc(callLogs.callStartTime))
    .limit(100);
}

export async function getRunningCampaigns(userId: number): Promise<Campaign[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(campaigns)
    .where(
      and(
        eq(campaigns.userId, userId),
        eq(campaigns.status, "running")
      )
    )
    .orderBy(desc(campaigns.startedAt));
}

export async function getTodayCallLogs(userId: number): Promise<CallLog[]> {
  const db = await getDb();
  if (!db) return [];
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  return await db.select({
    id: callLogs.id,
    campaignId: callLogs.campaignId,
    contactId: callLogs.contactId,
    phone: callLogs.phone,
    status: callLogs.status,
    duration: callLogs.duration,
    ivrOption: callLogs.ivrOption,
    callStartTime: callLogs.callStartTime,
    callEndTime: callLogs.callEndTime,
    asteriskCallId: callLogs.asteriskCallId,
    createdAt: callLogs.createdAt,
  })
  .from(callLogs)
  .innerJoin(campaigns, eq(callLogs.campaignId, campaigns.id))
  .where(
    and(
      eq(campaigns.userId, userId),
      sql`${callLogs.callStartTime} >= ${today}`
    )
  );
}

// ============= IVR Actions Management =============
export async function createIVRAction(action: InsertIVRAction): Promise<IVRAction> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(ivrActions).values(action);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(ivrActions).where(eq(ivrActions.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getIVRActionsByCampaignId(campaignId: number): Promise<IVRAction[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(ivrActions)
    .where(eq(ivrActions.campaignId, campaignId))
    .orderBy(ivrActions.digit);
}

export async function updateIVRAction(id: number, data: Partial<InsertIVRAction>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(ivrActions).set(data).where(eq(ivrActions.id, id));
}

export async function deleteIVRAction(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(ivrActions).where(eq(ivrActions.id, id));
}

// ============= TTS Settings Management =============
export async function createTTSSetting(setting: InsertTTSSetting): Promise<TTSSetting> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(ttsSettings).values(setting);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(ttsSettings).where(eq(ttsSettings.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getTTSSettingByCampaignId(campaignId: number): Promise<TTSSetting | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(ttsSettings)
    .where(eq(ttsSettings.campaignId, campaignId))
    .limit(1);
  return result[0];
}

export async function updateTTSSetting(id: number, data: Partial<InsertTTSSetting>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(ttsSettings).set(data).where(eq(ttsSettings.id, id));
}

// ============= TTS Cache Management =============
export async function getTTSCacheEntry(text: string, language: string, voice: string): Promise<TTSCache | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(ttsCache)
    .where(
      and(
        eq(ttsCache.text, text),
        eq(ttsCache.language, language),
        eq(ttsCache.voice, voice),
        sql`${ttsCache.expiresAt} IS NULL OR ${ttsCache.expiresAt} > NOW()`
      )
    )
    .limit(1);
  return result[0];
}

export async function createTTSCacheEntry(entry: InsertTTSCache): Promise<TTSCache> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(ttsCache).values(entry);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(ttsCache).where(eq(ttsCache.id, insertedId)).limit(1);
  return inserted[0]!;
}

// ============= Campaign Pause State Management =============
export async function createCampaignPauseState(state: InsertCampaignPauseState): Promise<CampaignPauseState> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(campaignPauseState).values(state);
  const insertedId = Number(result[0].insertId);
  const inserted = await db.select().from(campaignPauseState).where(eq(campaignPauseState.id, insertedId)).limit(1);
  return inserted[0]!;
}

export async function getPauseStateByCampaignId(campaignId: number): Promise<CampaignPauseState | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(campaignPauseState)
    .where(eq(campaignPauseState.campaignId, campaignId))
    .limit(1);
  return result[0];
}

export async function updatePauseState(campaignId: number, data: Partial<InsertCampaignPauseState>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(campaignPauseState)
    .set(data)
    .where(eq(campaignPauseState.campaignId, campaignId));
}

// ============= Extension Status Management =============
export async function getExtensionStatus(extensionId: number): Promise<ExtensionStatus | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(extensionStatus)
    .where(eq(extensionStatus.extensionId, extensionId))
    .limit(1);
  return result[0];
}

export async function getAllExtensionStatus(): Promise<ExtensionStatus[]> {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(extensionStatus);
}

export async function updateExtensionStatus(extensionId: number, data: Partial<InsertExtensionStatus>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getExtensionStatus(extensionId);
  
  if (existing) {
    await db.update(extensionStatus)
      .set(data)
      .where(eq(extensionStatus.extensionId, extensionId));
  } else {
    await db.insert(extensionStatus).values({
      extensionId,
      ...data,
    } as InsertExtensionStatus);
  }
}
