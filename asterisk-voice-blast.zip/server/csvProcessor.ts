/**
 * CSV Processing Module
 * Handles CSV file parsing and validation for contact imports
 */

export interface CSVContact {
  name: string;
  phone: string;
  email?: string;
  customField1?: string;
  customField2?: string;
  customField3?: string;
  customField4?: string;
  customField5?: string;
}

export interface CSVParseResult {
  success: boolean;
  contacts: CSVContact[];
  errors: string[];
  totalRows: number;
  validRows: number;
}

/**
 * Parse CSV content and extract contacts
 */
export function parseCSV(csvContent: string): CSVParseResult {
  const result: CSVParseResult = {
    success: false,
    contacts: [],
    errors: [],
    totalRows: 0,
    validRows: 0,
  };

  try {
    const lines = csvContent.split('\n').filter(line => line.trim());
    
    if (lines.length === 0) {
      result.errors.push("CSV file is empty");
      return result;
    }

    // Parse header
    const header = parseCSVLine(lines[0] || "");
    const nameIndex = findColumnIndex(header, ['name', 'nome', 'cliente']);
    const phoneIndex = findColumnIndex(header, ['phone', 'telefone', 'tel', 'celular']);
    const emailIndex = findColumnIndex(header, ['email', 'e-mail']);

    if (nameIndex === -1) {
      result.errors.push("Column 'name' or 'nome' not found in CSV header");
      return result;
    }

    if (phoneIndex === -1) {
      result.errors.push("Column 'phone' or 'telefone' not found in CSV header");
      return result;
    }

    // Parse data rows
    for (let i = 1; i < lines.length; i++) {
      result.totalRows++;
      const line = lines[i];
      if (!line || !line.trim()) continue;

      const columns = parseCSVLine(line);
      
      const name = columns[nameIndex]?.trim();
      const phone = columns[phoneIndex]?.trim();
      
      if (!name || !phone) {
        result.errors.push(`Row ${i + 1}: Missing name or phone`);
        continue;
      }

      // Validate and clean phone number
      const cleanPhone = cleanPhoneNumber(phone);
      if (!isValidPhone(cleanPhone)) {
        result.errors.push(`Row ${i + 1}: Invalid phone number: ${phone}`);
        continue;
      }

      const contact: CSVContact = {
        name,
        phone: cleanPhone,
      };

      if (emailIndex !== -1 && columns[emailIndex]) {
        contact.email = columns[emailIndex].trim();
      }

      // Map additional custom fields
      let customFieldIndex = 1;
      for (let j = 0; j < columns.length; j++) {
        if (j !== nameIndex && j !== phoneIndex && j !== emailIndex && columns[j]) {
          const fieldKey = `customField${customFieldIndex}` as keyof CSVContact;
          if (customFieldIndex <= 5) {
            contact[fieldKey] = columns[j].trim();
            customFieldIndex++;
          }
        }
      }

      result.contacts.push(contact);
      result.validRows++;
    }

    result.success = result.validRows > 0;
    
    if (result.validRows === 0 && result.totalRows > 0) {
      result.errors.push("No valid contacts found in CSV");
    }

  } catch (error) {
    result.errors.push(`Failed to parse CSV: ${error instanceof Error ? error.message : "Unknown error"}`);
  }

  return result;
}

/**
 * Parse a single CSV line handling quoted fields
 */
function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current);
  return result.map(field => field.trim());
}

/**
 * Find column index by multiple possible names (case-insensitive)
 */
function findColumnIndex(header: string[], possibleNames: string[]): number {
  const lowerHeader = header.map(h => h.toLowerCase().trim());
  
  for (const name of possibleNames) {
    const index = lowerHeader.indexOf(name.toLowerCase());
    if (index !== -1) return index;
  }
  
  return -1;
}

/**
 * Clean phone number - remove non-digit characters
 */
function cleanPhoneNumber(phone: string): string {
  return phone.replace(/\D/g, '');
}

/**
 * Validate phone number (Brazilian format)
 * Accepts: 10 digits (landline) or 11 digits (mobile)
 */
function isValidPhone(phone: string): boolean {
  const digits = phone.replace(/\D/g, '');
  
  // Brazilian phone numbers: 10 or 11 digits
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // Basic validation - starts with valid area code (11-99)
  const areaCode = parseInt(digits.substring(0, 2));
  if (areaCode < 11 || areaCode > 99) {
    return false;
  }
  
  return true;
}

/**
 * Format phone number for display
 */
export function formatPhoneNumber(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  
  if (digits.length === 11) {
    // Mobile: (XX) 9XXXX-XXXX
    return `(${digits.substring(0, 2)}) ${digits.substring(2, 7)}-${digits.substring(7)}`;
  } else if (digits.length === 10) {
    // Landline: (XX) XXXX-XXXX
    return `(${digits.substring(0, 2)}) ${digits.substring(2, 6)}-${digits.substring(6)}`;
  }
  
  return phone;
}

/**
 * Generate sample CSV template
 */
export function generateCSVTemplate(): string {
  const header = "name,phone,email,customField1,customField2,customField3,customField4,customField5";
  const sample1 = "João Silva,11987654321,joao@example.com,Campo1,Campo2,Campo3,Campo4,Campo5";
  const sample2 = "Maria Santos,21976543210,maria@example.com,Dado1,Dado2,Dado3,Dado4,Dado5";
  
  return `${header}\n${sample1}\n${sample2}\n`;
}
