import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("contacts procedures", () => {
  it("should list contacts successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contacts.list();
    
    expect(Array.isArray(result)).toBe(true);
  });

  it("should download CSV template successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contacts.downloadTemplate();
    
    expect(result).toHaveProperty("filename");
    expect(result).toHaveProperty("content");
    expect(result.filename).toContain(".csv");
    expect(result.content).toContain("name,phone,email");
  });
});

describe("audioFiles procedures", () => {
  it("should list campaign audio files successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.audioFiles.list({ type: "campaign" });
    
    expect(Array.isArray(result)).toBe(true);
  });

  it("should list MOH audio files successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.audioFiles.list({ type: "moh" });
    
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("campaigns procedures", () => {
  it("should list campaigns successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.campaigns.list();
    
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("extensions procedures", () => {
  it("should list extensions successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.extensions.list();
    
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("queues procedures", () => {
  it("should list queues successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.queues.list();
    
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("trunks procedures", () => {
  it("should list trunks successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.trunks.list();
    
    expect(Array.isArray(result)).toBe(true);
  });
});
