import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("monitoring procedures", () => {
  it("should get active calls successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.monitoring.activeCalls();
    
    expect(Array.isArray(result)).toBe(true);
  });

  it("should get live stats successfully", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.monitoring.liveStats();
    
    expect(result).toHaveProperty("runningCampaigns");
    expect(result).toHaveProperty("activeChannels");
    expect(result).toHaveProperty("todayStats");
    expect(result).toHaveProperty("campaigns");
    
    expect(typeof result.runningCampaigns).toBe("number");
    expect(typeof result.activeChannels).toBe("number");
    expect(Array.isArray(result.campaigns)).toBe(true);
    
    expect(result.todayStats).toHaveProperty("answered");
    expect(result.todayStats).toHaveProperty("noAnswer");
    expect(result.todayStats).toHaveProperty("busy");
    expect(result.todayStats).toHaveProperty("failed");
    expect(result.todayStats).toHaveProperty("voicemail");
    expect(result.todayStats).toHaveProperty("total");
  });
});
