#!/bin/bash

################################################################################
# Sistema de Disparos em Massa de Torpedos de Voz - Script de Instalação
# Compatível com Debian 11
# 
# Este script automatiza a instalação completa do sistema incluindo:
# - Asterisk 18.x
# - Node.js 22.x
# - MySQL/TiDB
# - Aplicação Web
# - Configuração de Systemd
#
# Uso: sudo bash install.sh
################################################################################

set -e

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções de logging
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Verificar se é root
if [[ $EUID -ne 0 ]]; then
   log_error "Este script deve ser executado como root (use sudo)"
   exit 1
fi

# Detectar distribuição
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    VERSION=$VERSION_ID
else
    log_error "Não foi possível detectar a distribuição Linux"
    exit 1
fi

if [ "$OS" != "debian" ] || [ "$VERSION" != "11" ]; then
    log_warning "Este script foi testado apenas em Debian 11"
    log_warning "Versão detectada: $OS $VERSION"
    read -p "Deseja continuar mesmo assim? (s/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Ss]$ ]]; then
        exit 1
    fi
fi

log_info "Iniciando instalação do Sistema de Disparos de Voz"
log_info "Sistema: $OS $VERSION"

# Atualizar sistema
log_info "Atualizando sistema..."
apt-get update
apt-get upgrade -y

# Instalar dependências básicas
log_info "Instalando dependências básicas..."
apt-get install -y \
    build-essential \
    wget \
    curl \
    git \
    vim \
    htop \
    net-tools \
    sudo \
    systemd \
    openssh-server \
    ufw

log_success "Dependências básicas instaladas"

# Instalar Asterisk
log_info "Instalando Asterisk 18.x..."
apt-get install -y \
    libssl-dev \
    libncurses5-dev \
    libnewt-dev \
    libxml2-dev \
    libsqlite3-dev \
    uuid-dev \
    libjansson-dev \
    linux-headers-$(uname -r)

# Download e compilação do Asterisk
cd /usr/src
if [ ! -d "asterisk-18" ]; then
    log_info "Baixando Asterisk 18..."
    wget -q http://downloads.asterisk.org/pub/telephony/asterisk/asterisk-18-current.tar.gz
    tar -xzf asterisk-18-current.tar.gz
    rm asterisk-18-current.tar.gz
fi

cd asterisk-18*/

log_info "Instalando dependências do Asterisk..."
./contrib/scripts/install_prereq install -y

log_info "Compilando Asterisk (isso pode levar alguns minutos)..."
./configure --with-pjproject-bundled > /dev/null 2>&1
make menuselect.makeopts
./menuselect/menuselect --enable-extra-sounds-en-gsm menuselect.makeopts
make -j$(nproc) > /dev/null 2>&1
make install > /dev/null 2>&1
make config > /dev/null 2>&1

log_success "Asterisk instalado com sucesso"

# Criar usuário asterisk
log_info "Configurando usuário Asterisk..."
if ! id -u asterisk > /dev/null 2>&1; then
    groupadd asterisk
    useradd -r -d /var/lib/asterisk -g asterisk asterisk
fi

chown -R asterisk:asterisk /etc/asterisk /var/lib/asterisk /var/log/asterisk /var/spool/asterisk /usr/lib/asterisk

# Configurar Asterisk para rodar como usuário asterisk
sed -i 's/#AST_USER="asterisk"/AST_USER="asterisk"/' /etc/default/asterisk
sed -i 's/#AST_GROUP="asterisk"/AST_GROUP="asterisk"/' /etc/default/asterisk

log_success "Usuário Asterisk configurado"

# Instalar Node.js
log_info "Instalando Node.js 22.x..."
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs

# Instalar pnpm
log_info "Instalando pnpm..."
npm install -g pnpm

log_success "Node.js e pnpm instalados"

# Instalar MySQL
log_info "Instalando MySQL 8.0..."
apt-get install -y mysql-server

# Iniciar MySQL
systemctl start mysql
systemctl enable mysql

log_success "MySQL instalado e iniciado"

# Criar banco de dados
log_info "Criando banco de dados..."
mysql -e "CREATE DATABASE IF NOT EXISTS asterisk_voice_blast CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -e "CREATE USER IF NOT EXISTS 'asterisk'@'localhost' IDENTIFIED BY 'asterisk_secure_password_123';"
mysql -e "GRANT ALL PRIVILEGES ON asterisk_voice_blast.* TO 'asterisk'@'localhost';"
mysql -e "FLUSH PRIVILEGES;"

log_success "Banco de dados criado"

# Instalar aplicação web
log_info "Instalando aplicação web..."
APP_DIR="/opt/asterisk-voice-blast"
mkdir -p $APP_DIR

# Copiar arquivos da aplicação (assumindo que estão no diretório atual)
if [ -f "package.json" ]; then
    cp -r . $APP_DIR/
    cd $APP_DIR
else
    log_warning "Arquivos da aplicação não encontrados no diretório atual"
    log_info "Você pode copiar manualmente para $APP_DIR"
    mkdir -p $APP_DIR
    cd $APP_DIR
fi

# Instalar dependências da aplicação
log_info "Instalando dependências da aplicação..."
pnpm install

# Configurar variáveis de ambiente
log_info "Configurando variáveis de ambiente..."
cat > .env.local << EOF
# Database
DATABASE_URL="mysql://asterisk:asterisk_secure_password_123@localhost:3306/asterisk_voice_blast"

# Asterisk AMI
ASTERISK_HOST=localhost
ASTERISK_PORT=5038
ASTERISK_USER=admin
ASTERISK_PASSWORD=asterisk_ami_password_123

# Application
VITE_APP_TITLE="Sistema de Disparos de Voz"
VITE_APP_ID=asterisk-voice-blast
NODE_ENV=production
PORT=3000

# JWT
JWT_SECRET=$(openssl rand -base64 32)

# OAuth (configure com suas credenciais Manus)
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# Storage (S3)
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_S3_BUCKET=your_bucket_name

# TTS Configuration
TTS_PROVIDER=google
TTS_LANGUAGE=pt-BR
TTS_VOICE=female

# Asterisk Configuration
ASTERISK_CONFIG_DIR=/etc/asterisk
ASTERISK_SOUNDS_DIR=/var/lib/asterisk/sounds
EOF

log_success "Variáveis de ambiente configuradas"

# Criar migrations do banco de dados
log_info "Criando tabelas do banco de dados..."
pnpm db:push

log_success "Banco de dados configurado"

# Configurar Asterisk Manager Interface (AMI)
log_info "Configurando Asterisk Manager Interface..."
cat > /etc/asterisk/manager.conf << 'EOF'
[general]
enabled = yes
port = 5038
bindaddr = 0.0.0.0
timestampevents = yes
defaultuser = admin
defaultpassword = asterisk_ami_password_123

[admin]
secret = asterisk_ami_password_123
deny=0.0.0.0/0.0.0.0
permit=127.0.0.1/255.255.255.0
permit=::1/128
read = system,call,log,verbose,command,agent,user,config,command,dtmf,reporting,cdr,dialplan,originate,message
write = system,call,log,verbose,command,agent,user,config,command,dtmf,reporting,cdr,dialplan,originate,message
EOF

chown asterisk:asterisk /etc/asterisk/manager.conf
chmod 600 /etc/asterisk/manager.conf

log_success "Asterisk Manager Interface configurado"

# Criar arquivo de dialplan básico
log_info "Criando dialplan básico..."
cat > /etc/asterisk/extensions_custom.conf << 'EOF'
[from-internal]
exten => _X.,1,NoOp(Chamada interna)
exten => _X.,n,Dial(SIP/${EXTEN})
exten => _X.,n,Hangup()

[from-external]
exten => _X.,1,NoOp(Chamada externa)
exten => _X.,n,Dial(SIP/${EXTEN})
exten => _X.,n,Hangup()
EOF

chown asterisk:asterisk /etc/asterisk/extensions_custom.conf

log_success "Dialplan básico criado"

# Criar serviço systemd para a aplicação
log_info "Criando serviço systemd..."
cat > /etc/systemd/system/asterisk-voice-blast.service << EOF
[Unit]
Description=Sistema de Disparos de Voz - Asterisk Voice Blast
After=network.target mysql.service asterisk.service
Wants=asterisk.service

[Service]
Type=simple
User=asterisk
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/pnpm start
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=asterisk-voice-blast

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable asterisk-voice-blast

log_success "Serviço systemd criado"

# Iniciar Asterisk
log_info "Iniciando Asterisk..."
systemctl start asterisk
systemctl enable asterisk

# Aguardar Asterisk iniciar
sleep 5

log_success "Asterisk iniciado"

# Iniciar aplicação web
log_info "Iniciando aplicação web..."
systemctl start asterisk-voice-blast

# Aguardar aplicação iniciar
sleep 10

log_success "Aplicação web iniciada"

# Configurar firewall
log_info "Configurando firewall..."
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 5060/udp
ufw allow 5061/tcp
ufw allow 5038/tcp
ufw allow 3000/tcp
ufw --force enable

log_success "Firewall configurado"

# Exibir informações finais
echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  Instalação Concluída com Sucesso!                        ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Informações de Acesso:${NC}"
echo "  Aplicação Web: http://$(hostname -I | awk '{print $1}'):3000"
echo "  Asterisk CLI: asterisk -r"
echo "  Logs da Aplicação: journalctl -u asterisk-voice-blast -f"
echo "  Logs do Asterisk: tail -f /var/log/asterisk/full"
echo ""
echo -e "${BLUE}Próximos Passos:${NC}"
echo "  1. Acesse a aplicação web e configure os troncos SIP"
echo "  2. Configure os ramais SIP"
echo "  3. Crie as filas de atendimento"
echo "  4. Importe contatos via CSV"
echo "  5. Configure e inicie campanhas"
echo ""
echo -e "${YELLOW}Credenciais Padrão:${NC}"
echo "  Banco de Dados:"
echo "    Usuário: asterisk"
echo "    Senha: asterisk_secure_password_123"
echo "  Asterisk AMI:"
echo "    Usuário: admin"
echo "    Senha: asterisk_ami_password_123"
echo ""
echo -e "${YELLOW}⚠ IMPORTANTE:${NC}"
echo "  - Altere as senhas padrão imediatamente!"
echo "  - Configure as credenciais S3 no arquivo .env.local"
echo "  - Configure as credenciais OAuth Manus"
echo "  - Faça backup regular do banco de dados"
echo ""

log_success "Instalação finalizada!"
