#!/bin/bash

################################################################################
# Script de Configuração Pós-Instalação
# Executa configurações adicionais e validações
################################################################################

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Verificar se é root
if [[ $EUID -ne 0 ]]; then
   log_error "Este script deve ser executado como root"
   exit 1
fi

APP_DIR="/opt/asterisk-voice-blast"

log_info "Executando configurações pós-instalação..."

# Validar instalação do Asterisk
log_info "Validando Asterisk..."
if command -v asterisk &> /dev/null; then
    ASTERISK_VERSION=$(asterisk -v | grep -oP 'Asterisk \K[0-9.]+')
    log_success "Asterisk $ASTERISK_VERSION instalado"
else
    log_error "Asterisk não encontrado"
    exit 1
fi

# Validar Node.js
log_info "Validando Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    log_success "Node.js $NODE_VERSION instalado"
else
    log_error "Node.js não encontrado"
    exit 1
fi

# Validar MySQL
log_info "Validando MySQL..."
if command -v mysql &> /dev/null; then
    MYSQL_VERSION=$(mysql -V | awk '{print $5}')
    log_success "MySQL $MYSQL_VERSION instalado"
else
    log_error "MySQL não encontrado"
    exit 1
fi

# Testar conexão com banco de dados
log_info "Testando conexão com banco de dados..."
if mysql -u asterisk -p asterisk_secure_password_123 -e "SELECT 1" asterisk_voice_blast > /dev/null 2>&1; then
    log_success "Banco de dados acessível"
else
    log_error "Erro ao conectar ao banco de dados"
    exit 1
fi

# Testar Asterisk AMI
log_info "Testando Asterisk AMI..."
if nc -z localhost 5038 > /dev/null 2>&1; then
    log_success "Asterisk AMI acessível na porta 5038"
else
    log_warning "Asterisk AMI não está respondendo"
fi

# Testar aplicação web
log_info "Testando aplicação web..."
sleep 5
if curl -s http://localhost:3000 > /dev/null; then
    log_success "Aplicação web acessível na porta 3000"
else
    log_warning "Aplicação web pode estar iniciando ainda"
fi

# Criar diretórios de logs
log_info "Criando diretórios de logs..."
mkdir -p /var/log/asterisk-voice-blast
chown asterisk:asterisk /var/log/asterisk-voice-blast
chmod 755 /var/log/asterisk-voice-blast
log_success "Diretórios de logs criados"

# Configurar rotação de logs
log_info "Configurando rotação de logs..."
cat > /etc/logrotate.d/asterisk-voice-blast << 'EOF'
/var/log/asterisk-voice-blast/*.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 asterisk asterisk
    sharedscripts
    postrotate
        systemctl reload asterisk-voice-blast > /dev/null 2>&1 || true
    endscript
}
EOF
log_success "Rotação de logs configurada"

# Criar script de monitoramento
log_info "Criando script de monitoramento..."
cat > /usr/local/bin/asterisk-voice-blast-monitor << 'EOF'
#!/bin/bash

# Verificar status dos serviços
echo "=== Status dos Serviços ==="
systemctl status asterisk --no-pager | grep -E "Active|Loaded"
systemctl status asterisk-voice-blast --no-pager | grep -E "Active|Loaded"
systemctl status mysql --no-pager | grep -E "Active|Loaded"

echo ""
echo "=== Conexões Asterisk ==="
asterisk -rx "core show channels" 2>/dev/null || echo "Asterisk não está respondendo"

echo ""
echo "=== Uso de Memória ==="
free -h | grep -E "Mem|Swap"

echo ""
echo "=== Espaço em Disco ==="
df -h /

echo ""
echo "=== Últimos Erros ==="
tail -10 /var/log/asterisk/full 2>/dev/null || echo "Nenhum log disponível"
EOF

chmod +x /usr/local/bin/asterisk-voice-blast-monitor
log_success "Script de monitoramento criado"

# Criar script de troubleshooting
log_info "Criando script de troubleshooting..."
cat > /usr/local/bin/asterisk-voice-blast-troubleshoot << 'EOF'
#!/bin/bash

echo "=== Troubleshooting Asterisk Voice Blast ==="
echo ""

# Verificar portas
echo "1. Verificando portas abertas..."
netstat -tlnp 2>/dev/null | grep -E "3000|5038|5060|3306" || echo "Nenhuma porta encontrada"

echo ""
echo "2. Verificando logs de erro..."
grep -i "error\|failed" /var/log/asterisk/full 2>/dev/null | tail -5 || echo "Nenhum erro encontrado"

echo ""
echo "3. Verificando logs da aplicação..."
journalctl -u asterisk-voice-blast -n 20 --no-pager 2>/dev/null || echo "Nenhum log disponível"

echo ""
echo "4. Verificando permissões..."
ls -la /etc/asterisk/manager.conf
ls -la /opt/asterisk-voice-blast/.env.local

echo ""
echo "5. Verificando conectividade..."
ping -c 1 localhost > /dev/null && echo "✓ Localhost acessível"
mysql -u asterisk -p asterisk_secure_password_123 -e "SELECT 1" > /dev/null 2>&1 && echo "✓ MySQL acessível"
curl -s http://localhost:3000 > /dev/null && echo "✓ Aplicação web acessível"
EOF

chmod +x /usr/local/bin/asterisk-voice-blast-troubleshoot
log_success "Script de troubleshooting criado"

# Criar cron job para backup automático
log_info "Configurando backup automático..."
cat > /etc/cron.d/asterisk-voice-blast-backup << 'EOF'
# Backup diário às 2:00 AM
0 2 * * * root /opt/asterisk-voice-blast/install/backup.sh backup > /var/log/asterisk-voice-blast/backup.log 2>&1

# Limpeza de backups antigos (mais de 30 dias) toda segunda-feira
0 3 * * 1 root /opt/asterisk-voice-blast/install/backup.sh cleanup 30 > /var/log/asterisk-voice-blast/cleanup.log 2>&1
EOF
chmod 644 /etc/cron.d/asterisk-voice-blast-backup
log_success "Backup automático configurado"

# Criar arquivo de status
log_info "Criando arquivo de status..."
cat > /opt/asterisk-voice-blast/INSTALLATION_STATUS.txt << EOF
=== Instalação do Sistema de Disparos de Voz ===
Data de Instalação: $(date)
Sistema Operacional: $(lsb_release -d | cut -f2)
Asterisk: $(asterisk -v | grep -oP 'Asterisk \K[0-9.]+')
Node.js: $(node -v)
MySQL: $(mysql -V | awk '{print $5}')

=== URLs de Acesso ===
Aplicação Web: http://$(hostname -I | awk '{print $1}'):3000
Asterisk CLI: asterisk -r

=== Comandos Úteis ===
Status dos serviços: systemctl status asterisk-voice-blast
Ver logs: journalctl -u asterisk-voice-blast -f
Monitorar: asterisk-voice-blast-monitor
Troubleshoot: asterisk-voice-blast-troubleshoot
Backup: /opt/asterisk-voice-blast/install/backup.sh

=== Próximas Etapas ===
1. Acesse a aplicação web
2. Configure os troncos SIP
3. Configure os ramais
4. Crie as filas
5. Importe contatos
6. Configure campanhas

=== Suporte ===
Documentação: /opt/asterisk-voice-blast/DOCUMENTATION.md
Logs: /var/log/asterisk-voice-blast/
Asterisk Logs: /var/log/asterisk/
EOF

log_success "Arquivo de status criado"

# Exibir resumo
echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  Configuração Pós-Instalação Concluída!                   ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BLUE}Próximos passos:${NC}"
echo "  1. Acesse a aplicação: http://$(hostname -I | awk '{print $1}'):3000"
echo "  2. Configure as credenciais OAuth Manus"
echo "  3. Configure as credenciais S3"
echo "  4. Configure os troncos SIP"
echo ""
echo -e "${BLUE}Comandos úteis:${NC}"
echo "  asterisk-voice-blast-monitor    # Ver status dos serviços"
echo "  asterisk-voice-blast-troubleshoot # Diagnosticar problemas"
echo "  /opt/asterisk-voice-blast/install/backup.sh backup # Fazer backup"
echo ""
echo -e "${YELLOW}⚠ Lembre-se:${NC}"
echo "  - Altere as senhas padrão"
echo "  - Configure as credenciais externas"
echo "  - Faça backups regulares"
echo "  - Monitore os logs regularmente"
echo ""

log_success "Sistema pronto para uso!"
