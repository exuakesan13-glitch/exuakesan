#!/bin/bash

################################################################################
# Script de Backup e Restauração
# Realiza backup do banco de dados e configurações do Asterisk
################################################################################

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Variáveis
BACKUP_DIR="/var/backups/asterisk-voice-blast"
DB_USER="asterisk"
DB_NAME="asterisk_voice_blast"
ASTERISK_CONFIG_DIR="/etc/asterisk"
APP_DIR="/opt/asterisk-voice-blast"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Criar diretório de backup
mkdir -p $BACKUP_DIR

case "${1:-backup}" in
    backup)
        log_info "Iniciando backup..."
        
        # Backup do banco de dados
        log_info "Fazendo backup do banco de dados..."
        BACKUP_FILE="$BACKUP_DIR/asterisk_voice_blast_$TIMESTAMP.sql"
        mysqldump -u $DB_USER -p $DB_NAME > $BACKUP_FILE 2>/dev/null || {
            log_error "Erro ao fazer backup do banco de dados"
            exit 1
        }
        log_success "Banco de dados: $BACKUP_FILE"
        
        # Backup das configurações do Asterisk
        log_info "Fazendo backup das configurações do Asterisk..."
        ASTERISK_BACKUP="$BACKUP_DIR/asterisk_config_$TIMESTAMP.tar.gz"
        tar -czf $ASTERISK_BACKUP -C /etc asterisk/ 2>/dev/null || {
            log_error "Erro ao fazer backup do Asterisk"
            exit 1
        }
        log_success "Configurações Asterisk: $ASTERISK_BACKUP"
        
        # Backup dos áudios
        log_info "Fazendo backup dos áudios..."
        AUDIO_BACKUP="$BACKUP_DIR/asterisk_sounds_$TIMESTAMP.tar.gz"
        tar -czf $AUDIO_BACKUP -C /var/lib/asterisk sounds/ 2>/dev/null || {
            log_error "Erro ao fazer backup dos áudios"
            exit 1
        }
        log_success "Áudios: $AUDIO_BACKUP"
        
        # Backup da aplicação
        log_info "Fazendo backup da aplicação..."
        APP_BACKUP="$BACKUP_DIR/app_$TIMESTAMP.tar.gz"
        tar -czf $APP_BACKUP -C /opt asterisk-voice-blast/ --exclude=node_modules --exclude=.git 2>/dev/null || {
            log_error "Erro ao fazer backup da aplicação"
            exit 1
        }
        log_success "Aplicação: $APP_BACKUP"
        
        # Criar arquivo de metadados
        cat > "$BACKUP_DIR/backup_$TIMESTAMP.info" << EOF
Backup realizado em: $(date)
Banco de dados: $BACKUP_FILE
Configurações Asterisk: $ASTERISK_BACKUP
Áudios: $AUDIO_BACKUP
Aplicação: $APP_BACKUP
EOF
        
        log_success "Backup completo realizado com sucesso!"
        log_info "Arquivos salvos em: $BACKUP_DIR"
        ;;
        
    restore)
        if [ -z "$2" ]; then
            log_error "Especifique o timestamp do backup para restaurar"
            log_info "Backups disponíveis:"
            ls -la $BACKUP_DIR/backup_*.info 2>/dev/null | awk '{print $NF}' | sed 's/.*backup_//g' | sed 's/.info//g'
            exit 1
        fi
        
        RESTORE_TIMESTAMP=$2
        
        log_info "Restaurando backup de $RESTORE_TIMESTAMP..."
        
        # Verificar se os arquivos existem
        if [ ! -f "$BACKUP_DIR/asterisk_voice_blast_$RESTORE_TIMESTAMP.sql" ]; then
            log_error "Arquivo de banco de dados não encontrado"
            exit 1
        fi
        
        # Parar serviços
        log_info "Parando serviços..."
        systemctl stop asterisk-voice-blast || true
        systemctl stop asterisk || true
        
        # Restaurar banco de dados
        log_info "Restaurando banco de dados..."
        mysql -u $DB_USER -p < "$BACKUP_DIR/asterisk_voice_blast_$RESTORE_TIMESTAMP.sql" 2>/dev/null || {
            log_error "Erro ao restaurar banco de dados"
            exit 1
        }
        log_success "Banco de dados restaurado"
        
        # Restaurar configurações Asterisk
        if [ -f "$BACKUP_DIR/asterisk_config_$RESTORE_TIMESTAMP.tar.gz" ]; then
            log_info "Restaurando configurações Asterisk..."
            tar -xzf "$BACKUP_DIR/asterisk_config_$RESTORE_TIMESTAMP.tar.gz" -C /etc/
            log_success "Configurações Asterisk restauradas"
        fi
        
        # Restaurar áudios
        if [ -f "$BACKUP_DIR/asterisk_sounds_$RESTORE_TIMESTAMP.tar.gz" ]; then
            log_info "Restaurando áudios..."
            tar -xzf "$BACKUP_DIR/asterisk_sounds_$RESTORE_TIMESTAMP.tar.gz" -C /var/lib/asterisk/
            log_success "Áudios restaurados"
        fi
        
        # Iniciar serviços
        log_info "Iniciando serviços..."
        systemctl start asterisk
        sleep 5
        systemctl start asterisk-voice-blast
        
        log_success "Restauração completa!"
        ;;
        
    list)
        log_info "Backups disponíveis:"
        ls -lh $BACKUP_DIR/backup_*.info 2>/dev/null | awk '{print $NF}' | sed 's/.*backup_//g' | sed 's/.info//g' || {
            log_error "Nenhum backup encontrado"
        }
        ;;
        
    cleanup)
        DAYS=${2:-30}
        log_info "Removendo backups com mais de $DAYS dias..."
        find $BACKUP_DIR -name "backup_*.info" -mtime +$DAYS -delete
        find $BACKUP_DIR -name "asterisk_*.sql" -mtime +$DAYS -delete
        find $BACKUP_DIR -name "asterisk_*.tar.gz" -mtime +$DAYS -delete
        find $BACKUP_DIR -name "app_*.tar.gz" -mtime +$DAYS -delete
        log_success "Limpeza concluída"
        ;;
        
    *)
        echo "Uso: $0 {backup|restore <timestamp>|list|cleanup [dias]}"
        echo ""
        echo "Exemplos:"
        echo "  $0 backup              # Criar novo backup"
        echo "  $0 list                # Listar backups disponíveis"
        echo "  $0 restore 20240101_120000  # Restaurar backup específico"
        echo "  $0 cleanup 30          # Remover backups com mais de 30 dias"
        exit 1
        ;;
esac
