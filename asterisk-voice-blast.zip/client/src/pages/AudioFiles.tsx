import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { Upload, Trash2, Play, AlertCircle, Mic, Music } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function AudioFiles() {
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [activeTab, setActiveTab] = useState<"campaign" | "moh">("campaign");

  const { data: campaignAudios, refetch: refetchCampaign } = trpc.audioFiles.list.useQuery({ type: "campaign" });
  const { data: mohAudios, refetch: refetchMoh } = trpc.audioFiles.list.useQuery({ type: "moh" });
  const uploadMutation = trpc.audioFiles.upload.useMutation();
  const deleteMutation = trpc.audioFiles.delete.useMutation();

  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!audioFile) {
      toast.error("Selecione um arquivo de áudio");
      return;
    }

    const formData = new FormData(e.currentTarget);
    const name = formData.get("name") as string;
    const type = formData.get("type") as "campaign" | "moh";

    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64 = event.target?.result as string;
        const base64Data = base64.split(',')[1];

        await uploadMutation.mutateAsync({
          name,
          filename: audioFile.name,
          fileData: base64Data || "",
          mimeType: audioFile.type,
          type,
        });

        toast.success("Áudio enviado com sucesso!");
        setIsUploadDialogOpen(false);
        setAudioFile(null);
        
        if (type === "campaign") {
          refetchCampaign();
        } else {
          refetchMoh();
        }
      };
      
      reader.readAsDataURL(audioFile);
    } catch (error) {
      toast.error("Erro ao enviar áudio");
    }
  };

  const handleDelete = async (id: number, type: "campaign" | "moh") => {
    if (!confirm("Tem certeza que deseja excluir este áudio?")) return;
    
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Áudio excluído com sucesso!");
      
      if (type === "campaign") {
        refetchCampaign();
      } else {
        refetchMoh();
      }
    } catch (error) {
      toast.error("Erro ao excluir áudio");
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  const formatDuration = (seconds: number | null) => {
    if (!seconds) return '-';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Arquivos de Áudio</h1>
            <p className="text-muted-foreground">Gerencie áudios para campanhas e música de espera</p>
          </div>
          <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Upload className="h-4 w-4 mr-2" />
                Upload de Áudio
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Upload de Arquivo de Áudio</DialogTitle>
                <DialogDescription>
                  Envie um arquivo de áudio para usar em campanhas ou como música de espera
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleUpload}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nome do Áudio *</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div>
                    <Label htmlFor="type">Tipo *</Label>
                    <Select name="type" defaultValue="campaign" required>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="campaign">Áudio de Campanha</SelectItem>
                        <SelectItem value="moh">Música de Espera (MOH)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="audio-file">Arquivo de Áudio *</Label>
                    <Input
                      id="audio-file"
                      type="file"
                      accept="audio/*,.wav,.mp3,.gsm"
                      onChange={(e) => setAudioFile(e.target.files?.[0] || null)}
                      required
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Formatos aceitos: WAV, MP3, GSM
                    </p>
                  </div>
                </div>
                <DialogFooter className="mt-6">
                  <Button type="submit" disabled={!audioFile || uploadMutation.isPending}>
                    {uploadMutation.isPending ? "Enviando..." : "Enviar"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "campaign" | "moh")}>
          <TabsList>
            <TabsTrigger value="campaign">
              <Mic className="h-4 w-4 mr-2" />
              Áudios de Campanha
            </TabsTrigger>
            <TabsTrigger value="moh">
              <Music className="h-4 w-4 mr-2" />
              Música de Espera
            </TabsTrigger>
          </TabsList>

          <TabsContent value="campaign">
            <Card>
              <CardHeader>
                <CardTitle>Áudios de Campanha</CardTitle>
                <CardDescription>
                  {campaignAudios?.length || 0} arquivo(s) disponível(is)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AudioTable
                  audios={campaignAudios || []}
                  onDelete={(id) => handleDelete(id, "campaign")}
                  formatFileSize={formatFileSize}
                  formatDuration={formatDuration}
                  isDeleting={deleteMutation.isPending}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="moh">
            <Card>
              <CardHeader>
                <CardTitle>Música de Espera (MOH)</CardTitle>
                <CardDescription>
                  {mohAudios?.length || 0} arquivo(s) disponível(is)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AudioTable
                  audios={mohAudios || []}
                  onDelete={(id) => handleDelete(id, "moh")}
                  formatFileSize={formatFileSize}
                  formatDuration={formatDuration}
                  isDeleting={deleteMutation.isPending}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}

interface AudioTableProps {
  audios: any[];
  onDelete: (id: number) => void;
  formatFileSize: (bytes: number) => string;
  formatDuration: (seconds: number | null) => string;
  isDeleting: boolean;
}

function AudioTable({ audios, onDelete, formatFileSize, formatDuration, isDeleting }: AudioTableProps) {
  if (audios.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">Nenhum áudio encontrado</h3>
        <p className="text-sm text-muted-foreground">
          Faça upload de arquivos de áudio para começar
        </p>
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Nome</TableHead>
          <TableHead>Arquivo</TableHead>
          <TableHead>Tamanho</TableHead>
          <TableHead>Duração</TableHead>
          <TableHead>Data</TableHead>
          <TableHead className="text-right">Ações</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {audios.map((audio) => (
          <TableRow key={audio.id}>
            <TableCell className="font-medium">{audio.name}</TableCell>
            <TableCell>{audio.filename}</TableCell>
            <TableCell>{formatFileSize(audio.fileSize)}</TableCell>
            <TableCell>{formatDuration(audio.duration)}</TableCell>
            <TableCell>{new Date(audio.createdAt).toLocaleDateString('pt-BR')}</TableCell>
            <TableCell className="text-right">
              <div className="flex justify-end gap-2">
                <Button variant="ghost" size="sm" asChild>
                  <a href={audio.fileUrl} target="_blank" rel="noopener noreferrer">
                    <Play className="h-4 w-4" />
                  </a>
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDelete(audio.id)}
                  disabled={isDeleting}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
