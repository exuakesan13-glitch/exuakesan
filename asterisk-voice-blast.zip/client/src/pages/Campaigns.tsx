import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/lib/trpc";
import { Plus, Play, Pause, Trash2, AlertCircle, Radio } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Campaigns() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedContacts, setSelectedContacts] = useState<number[]>([]);

  const { data: campaigns, refetch } = trpc.campaigns.list.useQuery();
  const { data: contacts } = trpc.contacts.list.useQuery();
  const { data: audioFiles } = trpc.audioFiles.list.useQuery({ type: "campaign" });
  const { data: trunks } = trpc.trunks.list.useQuery();
  
  const createMutation = trpc.campaigns.create.useMutation();
  const deleteMutation = trpc.campaigns.delete.useMutation();
  const startMutation = trpc.campaigns.start.useMutation();
  const pauseMutation = trpc.campaigns.pause.useMutation();
  const resumeMutation = trpc.campaigns.resume.useMutation();

  const handleCreate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    if (selectedContacts.length === 0) {
      toast.error("Selecione pelo menos um contato");
      return;
    }

    try {
      await createMutation.mutateAsync({
        name: formData.get("name") as string,
        audioFileId: parseInt(formData.get("audioFileId") as string),
        trunkId: parseInt(formData.get("trunkId") as string),
        maxConcurrentCalls: parseInt(formData.get("maxConcurrentCalls") as string),
        ivrEnabled: formData.get("ivrEnabled") === "on",
        contactIds: selectedContacts,
      });
      
      toast.success("Campanha criada com sucesso!");
      setIsCreateDialogOpen(false);
      setSelectedContacts([]);
      refetch();
    } catch (error) {
      toast.error("Erro ao criar campanha");
    }
  };

  const handleStart = async (id: number) => {
    try {
      await startMutation.mutateAsync({ id });
      toast.success("Campanha iniciada!");
      refetch();
    } catch (error) {
      toast.error("Erro ao iniciar campanha");
    }
  };

  const handlePause = async (id: number) => {
    try {
      await pauseMutation.mutateAsync({ id });
      toast.success("Campanha pausada!");
      refetch();
    } catch (error) {
      toast.error("Erro ao pausar campanha");
    }
  };

  const handleResume = async (id: number) => {
    try {
      await resumeMutation.mutateAsync({ id });
      toast.success("Campanha retomada!");
      refetch();
    } catch (error) {
      toast.error("Erro ao retomar campanha");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta campanha?")) return;
    
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Campanha excluída!");
      refetch();
    } catch (error) {
      toast.error("Erro ao excluir campanha");
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Campanhas</h1>
            <p className="text-muted-foreground">Gerencie suas campanhas de disparos em massa</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nova Campanha
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Criar Nova Campanha</DialogTitle>
                <DialogDescription>Configure os parâmetros da campanha de disparos</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nome da Campanha *</Label>
                    <Input id="name" name="name" required />
                  </div>

                  <div>
                    <Label htmlFor="audioFileId">Áudio da Campanha *</Label>
                    <Select name="audioFileId" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um áudio" />
                      </SelectTrigger>
                      <SelectContent>
                        {audioFiles?.map((audio) => (
                          <SelectItem key={audio.id} value={audio.id.toString()}>
                            {audio.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="trunkId">Tronco SIP *</Label>
                    <Select name="trunkId" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um tronco" />
                      </SelectTrigger>
                      <SelectContent>
                        {trunks?.map((trunk) => (
                          <SelectItem key={trunk.id} value={trunk.id.toString()}>
                            {trunk.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="maxConcurrentCalls">Chamadas Simultâneas *</Label>
                    <Input
                      id="maxConcurrentCalls"
                      name="maxConcurrentCalls"
                      type="number"
                      min="1"
                      max="1000"
                      defaultValue="10"
                      required
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch id="ivrEnabled" name="ivrEnabled" />
                    <Label htmlFor="ivrEnabled">Habilitar Menu IVR</Label>
                  </div>

                  <div>
                    <Label>Selecionar Contatos *</Label>
                    <div className="border rounded-lg p-4 max-h-48 overflow-y-auto space-y-2">
                      {contacts?.map((contact) => (
                        <div key={contact.id} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={`contact-${contact.id}`}
                            checked={selectedContacts.includes(contact.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedContacts([...selectedContacts, contact.id]);
                              } else {
                                setSelectedContacts(selectedContacts.filter(id => id !== contact.id));
                              }
                            }}
                            className="rounded border-gray-300"
                          />
                          <label htmlFor={`contact-${contact.id}`} className="text-sm">
                            {contact.name} - {contact.phone}
                          </label>
                        </div>
                      ))}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {selectedContacts.length} contato(s) selecionado(s)
                    </p>
                  </div>
                </div>
                <DialogFooter className="mt-6">
                  <Button type="submit" disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Criando..." : "Criar Campanha"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Campanhas</CardTitle>
            <CardDescription>
              {campaigns?.length || 0} campanha(s) cadastrada(s)
            </CardDescription>
          </CardHeader>
          <CardContent>
            {campaigns && campaigns.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Chamadas Simultâneas</TableHead>
                    <TableHead>IVR</TableHead>
                    <TableHead>Criada em</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {campaigns.map((campaign) => (
                    <TableRow key={campaign.id}>
                      <TableCell className="font-medium">{campaign.name}</TableCell>
                      <TableCell>
                        <StatusBadge status={campaign.status} />
                      </TableCell>
                      <TableCell>{campaign.maxConcurrentCalls}</TableCell>
                      <TableCell>{campaign.ivrEnabled ? "Sim" : "Não"}</TableCell>
                      <TableCell>{new Date(campaign.createdAt).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          {campaign.status === "draft" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleStart(campaign.id)}
                              disabled={startMutation.isPending}
                            >
                              <Play className="h-4 w-4 text-green-500" />
                            </Button>
                          )}
                          {campaign.status === "running" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handlePause(campaign.id)}
                              disabled={pauseMutation.isPending}
                            >
                              <Pause className="h-4 w-4 text-yellow-500" />
                            </Button>
                          )}
                          {campaign.status === "paused" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleResume(campaign.id)}
                              disabled={resumeMutation.isPending}
                            >
                              <Play className="h-4 w-4 text-green-500" />
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(campaign.id)}
                            disabled={deleteMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhuma campanha encontrada</h3>
                <p className="text-sm text-muted-foreground">
                  Crie sua primeira campanha para começar os disparos
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusMap: Record<string, string> = {
    draft: "status-badge status-info",
    scheduled: "status-badge status-warning",
    running: "status-badge status-success",
    paused: "status-badge status-warning",
    completed: "status-badge",
    cancelled: "status-badge status-error",
  };

  const labelMap: Record<string, string> = {
    draft: "Rascunho",
    scheduled: "Agendada",
    running: "Em Execução",
    paused: "Pausada",
    completed: "Concluída",
    cancelled: "Cancelada",
  };

  return (
    <span className={statusMap[status] || "status-badge"}>
      {labelMap[status] || status}
    </span>
  );
}
