import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { AlertCircle, CheckCircle, XCircle, PhoneOff, Voicemail } from "lucide-react";
import { useState } from "react";

export default function Reports() {
  const [selectedCampaignId, setSelectedCampaignId] = useState<number | null>(null);

  const { data: campaigns } = trpc.campaigns.list.useQuery();
  const { data: callLogs } = trpc.reports.callLogs.useQuery(
    { campaignId: selectedCampaignId! },
    { enabled: !!selectedCampaignId }
  );
  const { data: stats } = trpc.reports.stats.useQuery(
    { campaignId: selectedCampaignId! },
    { enabled: !!selectedCampaignId }
  );

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Relatórios</h1>
          <p className="text-muted-foreground">Visualize métricas e logs de chamadas</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Selecionar Campanha</CardTitle>
            <CardDescription>Escolha uma campanha para visualizar os relatórios</CardDescription>
          </CardHeader>
          <CardContent>
            <Select onValueChange={(v) => setSelectedCampaignId(parseInt(v))}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma campanha" />
              </SelectTrigger>
              <SelectContent>
                {campaigns?.map((campaign) => (
                  <SelectItem key={campaign.id} value={campaign.id.toString()}>
                    {campaign.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {selectedCampaignId && stats && (
          <>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
              <StatCard
                title="Total"
                value={stats.total}
                icon={<AlertCircle className="h-4 w-4" />}
              />
              <StatCard
                title="Atendidas"
                value={stats.answered}
                icon={<CheckCircle className="h-4 w-4 text-green-500" />}
                color="green"
              />
              <StatCard
                title="Não Atendidas"
                value={stats.noAnswer}
                icon={<PhoneOff className="h-4 w-4 text-yellow-500" />}
                color="yellow"
              />
              <StatCard
                title="Ocupado"
                value={stats.busy}
                icon={<XCircle className="h-4 w-4 text-red-500" />}
                color="red"
              />
              <StatCard
                title="Caixa Postal"
                value={stats.voicemail}
                icon={<Voicemail className="h-4 w-4 text-blue-500" />}
                color="blue"
              />
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Logs de Chamadas</CardTitle>
                <CardDescription>Histórico detalhado de todas as chamadas</CardDescription>
              </CardHeader>
              <CardContent>
                {callLogs && callLogs.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Telefone</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Duração</TableHead>
                        <TableHead>Opção IVR</TableHead>
                        <TableHead>Data/Hora</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {callLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="font-medium">{log.phone}</TableCell>
                          <TableCell>
                            <StatusBadge status={log.status} />
                          </TableCell>
                          <TableCell>{log.duration}s</TableCell>
                          <TableCell>{log.ivrOption || "-"}</TableCell>
                          <TableCell>
                            {new Date(log.callStartTime).toLocaleString('pt-BR')}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Nenhuma chamada registrada</h3>
                    <p className="text-sm text-muted-foreground">
                      As chamadas aparecerão aqui quando a campanha for executada
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  color?: string;
}

function StatCard({ title, value, icon, color }: StatCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusMap: Record<string, string> = {
    answered: "status-badge status-success",
    "no-answer": "status-badge status-warning",
    busy: "status-badge status-error",
    failed: "status-badge status-error",
    voicemail: "status-badge status-info",
  };

  const labelMap: Record<string, string> = {
    answered: "Atendida",
    "no-answer": "Não Atendida",
    busy: "Ocupado",
    failed: "Falhou",
    voicemail: "Caixa Postal",
  };

  return (
    <span className={statusMap[status] || "status-badge"}>
      {labelMap[status] || status}
    </span>
  );
}
