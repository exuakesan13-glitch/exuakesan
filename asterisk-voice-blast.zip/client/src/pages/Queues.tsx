import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { Plus, Trash2, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Queues() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const { data: queues, refetch } = trpc.queues.list.useQuery();
  const createMutation = trpc.queues.create.useMutation();
  const deleteMutation = trpc.queues.delete.useMutation();

  const handleCreate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      await createMutation.mutateAsync({
        name: formData.get("name") as string,
        displayName: formData.get("displayName") as string,
        strategy: formData.get("strategy") as any,
        timeout: parseInt(formData.get("timeout") as string),
        retry: parseInt(formData.get("retry") as string),
        maxlen: parseInt(formData.get("maxlen") as string),
      });
      
      toast.success("Fila criada com sucesso!");
      setIsCreateDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao criar fila");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir esta fila?")) return;
    
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Fila excluída!");
      refetch();
    } catch (error) {
      toast.error("Erro ao excluir fila");
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Filas de Atendimento</h1>
            <p className="text-muted-foreground">Gerencie filas de espera e agentes</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nova Fila
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Nova Fila</DialogTitle>
                <DialogDescription>Configure uma nova fila de atendimento</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nome Técnico *</Label>
                    <Input id="name" name="name" placeholder="queue-vendas" required />
                  </div>
                  <div>
                    <Label htmlFor="displayName">Nome de Exibição *</Label>
                    <Input id="displayName" name="displayName" placeholder="Vendas" required />
                  </div>
                  <div>
                    <Label htmlFor="strategy">Estratégia *</Label>
                    <Select name="strategy" defaultValue="ringall" required>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ringall">Ring All</SelectItem>
                        <SelectItem value="leastrecent">Least Recent</SelectItem>
                        <SelectItem value="fewestcalls">Fewest Calls</SelectItem>
                        <SelectItem value="random">Random</SelectItem>
                        <SelectItem value="rrmemory">Round Robin Memory</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="timeout">Timeout (segundos) *</Label>
                    <Input id="timeout" name="timeout" type="number" defaultValue="30" required />
                  </div>
                  <div>
                    <Label htmlFor="retry">Retry (segundos) *</Label>
                    <Input id="retry" name="retry" type="number" defaultValue="5" required />
                  </div>
                  <div>
                    <Label htmlFor="maxlen">Máximo de Chamadas *</Label>
                    <Input id="maxlen" name="maxlen" type="number" defaultValue="0" required />
                  </div>
                </div>
                <DialogFooter className="mt-6">
                  <Button type="submit" disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Criando..." : "Criar"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Filas</CardTitle>
            <CardDescription>{queues?.length || 0} fila(s) configurada(s)</CardDescription>
          </CardHeader>
          <CardContent>
            {queues && queues.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Estratégia</TableHead>
                    <TableHead>Timeout</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {queues.map((queue) => (
                    <TableRow key={queue.id}>
                      <TableCell className="font-medium">{queue.displayName}</TableCell>
                      <TableCell>{queue.strategy}</TableCell>
                      <TableCell>{queue.timeout}s</TableCell>
                      <TableCell>
                        {queue.enabled ? (
                          <span className="status-badge status-success">Ativa</span>
                        ) : (
                          <span className="status-badge status-error">Inativa</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(queue.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhuma fila configurada</h3>
                <p className="text-sm text-muted-foreground">Crie sua primeira fila</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
