import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Activity, Phone, Radio, TrendingUp, Clock, CheckCircle, XCircle, PhoneOff, Voicemail } from "lucide-react";
import { useEffect } from "react";

export default function Monitoring() {
  const { data: liveStats, refetch: refetchStats } = trpc.monitoring.liveStats.useQuery();
  const { data: activeCalls, refetch: refetchCalls } = trpc.monitoring.activeCalls.useQuery();

  // Auto-refresh a cada 3 segundos
  useEffect(() => {
    const interval = setInterval(() => {
      refetchStats();
      refetchCalls();
    }, 3000);

    return () => clearInterval(interval);
  }, [refetchStats, refetchCalls]);

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Monitoramento em Tempo Real</h1>
            <p className="text-muted-foreground">Acompanhe chamadas ativas e métricas ao vivo</p>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Activity className="h-4 w-4 animate-pulse text-green-500" />
            <span>Atualização automática a cada 3s</span>
          </div>
        </div>

        {/* Métricas Principais */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <MetricCard
            title="Campanhas Ativas"
            value={liveStats?.runningCampaigns || 0}
            icon={<Radio className="h-5 w-5 text-blue-500" />}
            trend="+12%"
            description="Em execução agora"
          />
          <MetricCard
            title="Canais Ativos"
            value={liveStats?.activeChannels || 0}
            icon={<Phone className="h-5 w-5 text-green-500" />}
            description="Chamadas simultâneas"
          />
          <MetricCard
            title="Chamadas Hoje"
            value={liveStats?.todayStats.total || 0}
            icon={<TrendingUp className="h-5 w-5 text-purple-500" />}
            trend="+5%"
            description="Total de tentativas"
          />
          <MetricCard
            title="Taxa de Sucesso"
            value={
              liveStats?.todayStats.total
                ? `${Math.round((liveStats.todayStats.answered / liveStats.todayStats.total) * 100)}%`
                : "0%"
            }
            icon={<CheckCircle className="h-5 w-5 text-emerald-500" />}
            description="Chamadas atendidas"
          />
        </div>

        {/* Estatísticas Detalhadas de Hoje */}
        <Card>
          <CardHeader>
            <CardTitle>Estatísticas de Hoje</CardTitle>
            <CardDescription>Resumo de todas as chamadas realizadas hoje</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-5">
              <StatItem
                label="Atendidas"
                value={liveStats?.todayStats.answered || 0}
                icon={<CheckCircle className="h-4 w-4 text-green-500" />}
                color="green"
              />
              <StatItem
                label="Não Atendidas"
                value={liveStats?.todayStats.noAnswer || 0}
                icon={<PhoneOff className="h-4 w-4 text-yellow-500" />}
                color="yellow"
              />
              <StatItem
                label="Ocupado"
                value={liveStats?.todayStats.busy || 0}
                icon={<XCircle className="h-4 w-4 text-red-500" />}
                color="red"
              />
              <StatItem
                label="Caixa Postal"
                value={liveStats?.todayStats.voicemail || 0}
                icon={<Voicemail className="h-4 w-4 text-blue-500" />}
                color="blue"
              />
              <StatItem
                label="Falhas"
                value={liveStats?.todayStats.failed || 0}
                icon={<XCircle className="h-4 w-4 text-gray-500" />}
                color="gray"
              />
            </div>
          </CardContent>
        </Card>

        {/* Campanhas em Execução */}
        {liveStats?.campaigns && liveStats.campaigns.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Campanhas em Execução</CardTitle>
              <CardDescription>{liveStats.campaigns.length} campanha(s) ativa(s)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {liveStats.campaigns.map((campaign) => (
                  <div
                    key={campaign.id}
                    className="flex items-center justify-between p-4 border rounded-lg bg-card/50"
                  >
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center">
                        <Radio className="h-5 w-5 text-green-500 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{campaign.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          Máx. {campaign.maxConcurrentCalls} chamadas simultâneas
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {campaign.ivrEnabled && (
                        <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/20">
                          IVR Ativo
                        </Badge>
                      )}
                      <Badge className="bg-green-500/10 text-green-500 border-green-500/20">
                        Em Execução
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Chamadas Ativas */}
        <Card>
          <CardHeader>
            <CardTitle>Chamadas Ativas</CardTitle>
            <CardDescription>
              {activeCalls?.length || 0} chamada(s) em andamento nos últimos 5 minutos
            </CardDescription>
          </CardHeader>
          <CardContent>
            {activeCalls && activeCalls.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Telefone</TableHead>
                    <TableHead>Campanha</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Início</TableHead>
                    <TableHead>Duração</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeCalls.map((call) => (
                    <TableRow key={call.id}>
                      <TableCell className="font-medium">{call.phone}</TableCell>
                      <TableCell>
                        <Badge variant="outline">ID: {call.campaignId}</Badge>
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={call.status} />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Clock className="h-3 w-3 text-muted-foreground" />
                          {new Date(call.callStartTime).toLocaleTimeString('pt-BR')}
                        </div>
                      </TableCell>
                      <TableCell>
                        <LiveDuration startTime={call.callStartTime} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Phone className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhuma chamada ativa</h3>
                <p className="text-sm text-muted-foreground">
                  As chamadas em andamento aparecerão aqui em tempo real
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

interface MetricCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  trend?: string;
  description?: string;
}

function MetricCard({ title, value, icon, trend, description }: MetricCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center gap-2 mt-1">
          {trend && <span className="text-xs text-green-500 font-medium">{trend}</span>}
          {description && <p className="text-xs text-muted-foreground">{description}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

interface StatItemProps {
  label: string;
  value: number;
  icon: React.ReactNode;
  color: string;
}

function StatItem({ label, value, icon, color }: StatItemProps) {
  return (
    <div className="flex flex-col items-center justify-center p-4 border rounded-lg">
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <span className="text-sm font-medium text-muted-foreground">{label}</span>
      </div>
      <div className="text-2xl font-bold">{value}</div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusMap: Record<string, { label: string; className: string }> = {
    answered: { label: "Atendida", className: "bg-green-500/10 text-green-500 border-green-500/20" },
    "no-answer": { label: "Chamando", className: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20" },
    busy: { label: "Ocupado", className: "bg-red-500/10 text-red-500 border-red-500/20" },
    failed: { label: "Falhou", className: "bg-gray-500/10 text-gray-500 border-gray-500/20" },
    voicemail: { label: "Caixa Postal", className: "bg-blue-500/10 text-blue-500 border-blue-500/20" },
  };

  const config = statusMap[status] || { label: status, className: "" };

  return (
    <Badge variant="outline" className={config.className}>
      {config.label}
    </Badge>
  );
}

function LiveDuration({ startTime }: { startTime: Date }) {
  const [duration, setDuration] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      const seconds = Math.floor((Date.now() - new Date(startTime).getTime()) / 1000);
      setDuration(seconds);
    }, 1000);

    return () => clearInterval(interval);
  }, [startTime]);

  const minutes = Math.floor(duration / 60);
  const seconds = duration % 60;

  return (
    <div className="font-mono text-sm">
      {minutes}:{seconds.toString().padStart(2, '0')}
    </div>
  );
}

// Adicionar import do React no topo
import * as React from "react";
