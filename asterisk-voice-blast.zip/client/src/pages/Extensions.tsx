import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/lib/trpc";
import { Plus, Trash2, Edit, AlertCircle, Phone } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Extensions() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const { data: extensions, refetch } = trpc.extensions.list.useQuery();
  const createMutation = trpc.extensions.create.useMutation();
  const deleteMutation = trpc.extensions.delete.useMutation();

  const handleCreate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      await createMutation.mutateAsync({
        extension: formData.get("extension") as string,
        name: formData.get("name") as string,
        secret: formData.get("secret") as string,
        callerIdName: formData.get("callerIdName") as string || undefined,
        callerIdNumber: formData.get("callerIdNumber") as string || undefined,
      });
      
      toast.success("Ramal criado com sucesso!");
      setIsCreateDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao criar ramal");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este ramal?")) return;
    
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Ramal excluído!");
      refetch();
    } catch (error) {
      toast.error("Erro ao excluir ramal");
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Ramais SIP</h1>
            <p className="text-muted-foreground">Configure ramais para o sistema</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Novo Ramal
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Novo Ramal</DialogTitle>
                <DialogDescription>Configure um novo ramal SIP</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="extension">Número do Ramal *</Label>
                    <Input id="extension" name="extension" placeholder="1000" required />
                  </div>
                  <div>
                    <Label htmlFor="name">Nome *</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div>
                    <Label htmlFor="secret">Senha *</Label>
                    <Input id="secret" name="secret" type="password" required />
                  </div>
                  <div>
                    <Label htmlFor="callerIdName">Caller ID Nome</Label>
                    <Input id="callerIdName" name="callerIdName" />
                  </div>
                  <div>
                    <Label htmlFor="callerIdNumber">Caller ID Número</Label>
                    <Input id="callerIdNumber" name="callerIdNumber" />
                  </div>
                </div>
                <DialogFooter className="mt-6">
                  <Button type="submit" disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Criando..." : "Criar"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Ramais</CardTitle>
            <CardDescription>{extensions?.length || 0} ramal(is) configurado(s)</CardDescription>
          </CardHeader>
          <CardContent>
            {extensions && extensions.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ramal</TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Caller ID</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {extensions.map((ext) => (
                    <TableRow key={ext.id}>
                      <TableCell className="font-medium">{ext.extension}</TableCell>
                      <TableCell>{ext.name}</TableCell>
                      <TableCell>{ext.callerIdName || "-"}</TableCell>
                      <TableCell>
                        {ext.enabled ? (
                          <span className="status-badge status-success">Ativo</span>
                        ) : (
                          <span className="status-badge status-error">Inativo</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(ext.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum ramal configurado</h3>
                <p className="text-sm text-muted-foreground">Crie seu primeiro ramal</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
