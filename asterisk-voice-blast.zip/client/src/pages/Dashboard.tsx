import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Phone, Users, Mic, Activity, TrendingUp, AlertCircle } from "lucide-react";

export default function Dashboard() {
  const { data: campaigns } = trpc.campaigns.list.useQuery();
  const { data: contacts } = trpc.contacts.list.useQuery();
  const { data: audioFiles } = trpc.audioFiles.list.useQuery({});
  const { data: asteriskStatus } = trpc.status.asterisk.useQuery();
  const { data: activeChannels } = trpc.status.activeChannels.useQuery();

  const activeCampaigns = campaigns?.filter(c => c.status === "running").length || 0;
  const totalContacts = contacts?.length || 0;
  const totalAudios = audioFiles?.length || 0;
  const channelsCount = activeChannels?.count || 0;

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Visão geral do sistema de disparos em massa</p>
        </div>

        {/* Status Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Campanhas Ativas"
            value={activeCampaigns.toString()}
            description="Em execução agora"
            icon={<Activity className="h-4 w-4" />}
            trend="+12%"
          />
          
          <StatCard
            title="Total de Contatos"
            value={totalContacts.toString()}
            description="Contatos cadastrados"
            icon={<Users className="h-4 w-4" />}
            trend="+5%"
          />
          
          <StatCard
            title="Arquivos de Áudio"
            value={totalAudios.toString()}
            description="Áudios disponíveis"
            icon={<Mic className="h-4 w-4" />}
          />
          
          <StatCard
            title="Canais Ativos"
            value={channelsCount.toString()}
            description="Chamadas em andamento"
            icon={<Phone className="h-4 w-4" />}
          />
        </div>

        {/* System Status */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Status do Asterisk
              </CardTitle>
              <CardDescription>Status do servidor de telefonia</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Servidor</span>
                  {asteriskStatus?.running ? (
                    <span className="status-badge status-success">Online</span>
                  ) : (
                    <span className="status-badge status-error">Offline</span>
                  )}
                </div>
                {asteriskStatus?.version && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Versão</span>
                    <span className="text-sm text-muted-foreground">{asteriskStatus.version}</span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Canais Ativos</span>
                  <span className="text-sm text-muted-foreground">{channelsCount}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Campanhas Recentes
              </CardTitle>
              <CardDescription>Últimas campanhas criadas</CardDescription>
            </CardHeader>
            <CardContent>
              {campaigns && campaigns.length > 0 ? (
                <div className="space-y-3">
                  {campaigns.slice(0, 5).map((campaign) => (
                    <div key={campaign.id} className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{campaign.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(campaign.createdAt).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                      <StatusBadge status={campaign.status} />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <AlertCircle className="h-8 w-8 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">Nenhuma campanha criada</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Ações Rápidas</CardTitle>
            <CardDescription>Acesso rápido às principais funcionalidades</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <QuickActionCard
                title="Nova Campanha"
                description="Criar uma nova campanha de disparos"
                href="/campaigns"
              />
              <QuickActionCard
                title="Importar Contatos"
                description="Importar lista de contatos via CSV"
                href="/contacts"
              />
              <QuickActionCard
                title="Upload de Áudio"
                description="Fazer upload de novos áudios"
                href="/audio-files"
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

interface StatCardProps {
  title: string;
  value: string;
  description: string;
  icon: React.ReactNode;
  trend?: string;
}

function StatCard({ title, value, description, icon, trend }: StatCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">
          {description}
          {trend && <span className="text-green-500 ml-2">{trend}</span>}
        </p>
      </CardContent>
    </Card>
  );
}

interface QuickActionCardProps {
  title: string;
  description: string;
  href: string;
}

function QuickActionCard({ title, description, href }: QuickActionCardProps) {
  return (
    <a href={href} className="block">
      <div className="border border-border rounded-lg p-4 card-hover">
        <h4 className="font-semibold mb-1">{title}</h4>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </a>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusMap: Record<string, string> = {
    draft: "status-badge status-info",
    scheduled: "status-badge status-warning",
    running: "status-badge status-success",
    paused: "status-badge status-warning",
    completed: "status-badge",
    cancelled: "status-badge status-error",
  };

  const labelMap: Record<string, string> = {
    draft: "Rascunho",
    scheduled: "Agendada",
    running: "Em Execução",
    paused: "Pausada",
    completed: "Concluída",
    cancelled: "Cancelada",
  };

  return (
    <span className={statusMap[status] || "status-badge"}>
      {labelMap[status] || status}
    </span>
  );
}
