import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { Upload, Plus, Search, Trash2, Edit, Download, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Contacts() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [csvFile, setCsvFile] = useState<File | null>(null);

  const { data: contacts, refetch } = trpc.contacts.list.useQuery();
  const createMutation = trpc.contacts.create.useMutation();
  const deleteMutation = trpc.contacts.delete.useMutation();
  const importMutation = trpc.contacts.importCSV.useMutation();
  const { data: templateData } = trpc.contacts.downloadTemplate.useQuery();

  const filteredContacts = contacts?.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.phone.includes(searchTerm)
  );

  const handleAddContact = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      await createMutation.mutateAsync({
        name: formData.get("name") as string,
        phone: formData.get("phone") as string,
        email: formData.get("email") as string || undefined,
        customField1: formData.get("customField1") as string || undefined,
        customField2: formData.get("customField2") as string || undefined,
      });
      
      toast.success("Contato adicionado com sucesso!");
      setIsAddDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao adicionar contato");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este contato?")) return;
    
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Contato excluído com sucesso!");
      refetch();
    } catch (error) {
      toast.error("Erro ao excluir contato");
    }
  };

  const handleImportCSV = async () => {
    if (!csvFile) {
      toast.error("Selecione um arquivo CSV");
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      const csvContent = e.target?.result as string;
      
      try {
        const result = await importMutation.mutateAsync({ csvContent });
        
        if (result.success) {
          toast.success(`${result.imported} contatos importados com sucesso!`);
          if (result.errors.length > 0) {
            toast.warning(`${result.errors.length} erros encontrados`);
          }
          setIsImportDialogOpen(false);
          setCsvFile(null);
          refetch();
        } else {
          toast.error("Erro ao importar contatos");
          result.errors.forEach(error => toast.error(error));
        }
      } catch (error) {
        toast.error("Erro ao processar arquivo CSV");
      }
    };
    
    reader.readAsText(csvFile);
  };

  const downloadTemplate = () => {
    if (!templateData) return;
    
    const blob = new Blob([templateData.content], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = templateData.filename;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Contatos</h1>
            <p className="text-muted-foreground">Gerencie sua lista de contatos para campanhas</p>
          </div>
          <div className="flex gap-2">
            <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Upload className="h-4 w-4 mr-2" />
                  Importar CSV
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Importar Contatos via CSV</DialogTitle>
                  <DialogDescription>
                    Faça upload de um arquivo CSV com seus contatos. O arquivo deve conter as colunas: nome, telefone, email.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="csv-file">Arquivo CSV</Label>
                    <Input
                      id="csv-file"
                      type="file"
                      accept=".csv"
                      onChange={(e) => setCsvFile(e.target.files?.[0] || null)}
                    />
                  </div>
                  <Button variant="outline" onClick={downloadTemplate} className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Baixar Template CSV
                  </Button>
                </div>
                <DialogFooter>
                  <Button onClick={handleImportCSV} disabled={!csvFile || importMutation.isPending}>
                    {importMutation.isPending ? "Importando..." : "Importar"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar Contato
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Adicionar Novo Contato</DialogTitle>
                  <DialogDescription>Preencha os dados do contato</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleAddContact}>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">Nome *</Label>
                      <Input id="name" name="name" required />
                    </div>
                    <div>
                      <Label htmlFor="phone">Telefone *</Label>
                      <Input id="phone" name="phone" placeholder="11987654321" required />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" name="email" type="email" />
                    </div>
                    <div>
                      <Label htmlFor="customField1">Campo Customizado 1</Label>
                      <Input id="customField1" name="customField1" />
                    </div>
                    <div>
                      <Label htmlFor="customField2">Campo Customizado 2</Label>
                      <Input id="customField2" name="customField2" />
                    </div>
                  </div>
                  <DialogFooter className="mt-6">
                    <Button type="submit" disabled={createMutation.isPending}>
                      {createMutation.isPending ? "Salvando..." : "Salvar"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Contatos</CardTitle>
            <CardDescription>
              Total de {contacts?.length || 0} contatos cadastrados
            </CardDescription>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou telefone..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardHeader>
          <CardContent>
            {filteredContacts && filteredContacts.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Telefone</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Data de Cadastro</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredContacts.map((contact) => (
                    <TableRow key={contact.id}>
                      <TableCell className="font-medium">{contact.name}</TableCell>
                      <TableCell>{contact.phone}</TableCell>
                      <TableCell>{contact.email || "-"}</TableCell>
                      <TableCell>{new Date(contact.createdAt).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(contact.id)}
                            disabled={deleteMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum contato encontrado</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {searchTerm ? "Tente uma busca diferente" : "Adicione contatos manualmente ou importe via CSV"}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
