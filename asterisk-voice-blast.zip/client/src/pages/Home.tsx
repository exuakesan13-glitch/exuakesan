import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { APP_TITLE, getLoginUrl } from "@/const";
import { Phone, Users, BarChart3, Settings, Mic, Radio } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (isAuthenticated && user) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, user, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (isAuthenticated && user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Phone className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-bold">{APP_TITLE}</h1>
          </div>
          <Button asChild>
            <a href={getLoginUrl()}>Entrar</a>
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto text-center max-w-4xl">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary border border-primary/20 mb-6">
            <Radio className="h-4 w-4" />
            <span className="text-sm font-medium">Sistema Profissional de Call Center</span>
          </div>
          
          <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent">
            Disparos em Massa de Torpedos de Voz
          </h2>
          
          <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
            Plataforma completa para gerenciar campanhas de voz, ramais, filas de atendimento e troncos SIP. 
            Integração total com Asterisk para máxima performance e controle.
          </p>

          <div className="flex gap-4 justify-center">
            <Button size="lg" asChild>
              <a href={getLoginUrl()}>Começar Agora</a>
            </Button>
            <Button size="lg" variant="outline">
              Saiba Mais
            </Button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-6 bg-card/30">
        <div className="container mx-auto">
          <h3 className="text-3xl font-bold text-center mb-12">Funcionalidades Completas</h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard
              icon={<Users className="h-8 w-8" />}
              title="Gerenciamento de Contatos"
              description="Importe listas via CSV, organize e gerencie seus contatos de forma eficiente."
            />
            
            <FeatureCard
              icon={<Mic className="h-8 w-8" />}
              title="Upload de Áudios"
              description="Faça upload de áudios para campanhas e música de espera. Suporte a múltiplos formatos."
            />
            
            <FeatureCard
              icon={<Phone className="h-8 w-8" />}
              title="Ramais SIP"
              description="Configure e gerencie ramais SIP com total controle sobre as configurações."
            />
            
            <FeatureCard
              icon={<Users className="h-8 w-8" />}
              title="Filas de Atendimento"
              description="Crie filas de espera e configure agentes para otimizar o atendimento."
            />
            
            <FeatureCard
              icon={<Settings className="h-8 w-8" />}
              title="Troncos SIP"
              description="Adicione e configure troncos SIP externos para suas campanhas."
            />
            
            <FeatureCard
              icon={<BarChart3 className="h-8 w-8" />}
              title="Relatórios Detalhados"
              description="Acompanhe métricas de chamadas atendidas, rejeitadas, não atendidas e mais."
            />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div className="stat-card">
              <div className="text-4xl font-bold text-primary mb-2">99.9%</div>
              <div className="text-muted-foreground">Uptime Garantido</div>
            </div>
            
            <div className="stat-card">
              <div className="text-4xl font-bold text-primary mb-2">1000+</div>
              <div className="text-muted-foreground">Chamadas Simultâneas</div>
            </div>
            
            <div className="stat-card">
              <div className="text-4xl font-bold text-primary mb-2">24/7</div>
              <div className="text-muted-foreground">Monitoramento</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-r from-primary/10 to-blue-500/10 border-y border-border">
        <div className="container mx-auto text-center max-w-3xl">
          <h3 className="text-3xl font-bold mb-4">Pronto para Começar?</h3>
          <p className="text-lg text-muted-foreground mb-8">
            Crie sua conta agora e comece a gerenciar suas campanhas de voz com eficiência.
          </p>
          <Button size="lg" asChild>
            <a href={getLoginUrl()}>Criar Conta Grátis</a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-border">
        <div className="container mx-auto text-center text-muted-foreground">
          <p>© 2024 {APP_TITLE}. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="bg-card border border-border rounded-lg p-6 card-hover">
      <div className="text-primary mb-4">{icon}</div>
      <h4 className="text-lg font-semibold mb-2">{title}</h4>
      <p className="text-muted-foreground text-sm">{description}</p>
    </div>
  );
}
