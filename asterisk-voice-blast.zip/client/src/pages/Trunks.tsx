import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { Plus, Trash2, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Trunks() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  const { data: trunks, refetch } = trpc.trunks.list.useQuery();
  const createMutation = trpc.trunks.create.useMutation();
  const deleteMutation = trpc.trunks.delete.useMutation();

  const handleCreate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      await createMutation.mutateAsync({
        name: formData.get("name") as string,
        host: formData.get("host") as string,
        username: formData.get("username") as string,
        secret: formData.get("secret") as string,
        port: parseInt(formData.get("port") as string),
      });
      
      toast.success("Tronco SIP criado com sucesso!");
      setIsCreateDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao criar tronco SIP");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este tronco?")) return;
    
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Tronco excluído!");
      refetch();
    } catch (error) {
      toast.error("Erro ao excluir tronco");
    }
  };

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Troncos SIP</h1>
            <p className="text-muted-foreground">Configure troncos SIP externos</p>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Novo Tronco
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Criar Novo Tronco SIP</DialogTitle>
                <DialogDescription>Configure conexão com provedor SIP</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Nome *</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div>
                    <Label htmlFor="host">Servidor (Host) *</Label>
                    <Input id="host" name="host" placeholder="sip.provedor.com" required />
                  </div>
                  <div>
                    <Label htmlFor="username">Usuário *</Label>
                    <Input id="username" name="username" required />
                  </div>
                  <div>
                    <Label htmlFor="secret">Senha *</Label>
                    <Input id="secret" name="secret" type="password" required />
                  </div>
                  <div>
                    <Label htmlFor="port">Porta *</Label>
                    <Input id="port" name="port" type="number" defaultValue="5060" required />
                  </div>
                </div>
                <DialogFooter className="mt-6">
                  <Button type="submit" disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Criando..." : "Criar"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Lista de Troncos</CardTitle>
            <CardDescription>{trunks?.length || 0} tronco(s) configurado(s)</CardDescription>
          </CardHeader>
          <CardContent>
            {trunks && trunks.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Host</TableHead>
                    <TableHead>Usuário</TableHead>
                    <TableHead>Porta</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {trunks.map((trunk) => (
                    <TableRow key={trunk.id}>
                      <TableCell className="font-medium">{trunk.name}</TableCell>
                      <TableCell>{trunk.host}</TableCell>
                      <TableCell>{trunk.username}</TableCell>
                      <TableCell>{trunk.port}</TableCell>
                      <TableCell>
                        {trunk.enabled ? (
                          <span className="status-badge status-success">Ativo</span>
                        ) : (
                          <span className="status-badge status-error">Inativo</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(trunk.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhum tronco configurado</h3>
                <p className="text-sm text-muted-foreground">Adicione seu primeiro tronco SIP</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
